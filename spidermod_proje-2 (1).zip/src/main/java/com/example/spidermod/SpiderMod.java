package com.example.spidermod;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.lwjgl.glfw.GLFW;

/**
 * Spider Mod (Forge 1.20.1)
 *  - Orumcek Adam Kostumu (gogusluk): giyince TUM VUCUT kostum olur
 *  - Kostum giyiliyken: duvarin onunde EGILIRKEN ZIPLA -> tirmanma modu acilir (tus basili tutmak gerekmez),
 *    W yukari, S asagi, SPACE duvardan siçra, SHIFT+SPACE birak. Dusme hasari azalir
 *  - Y tusu: Web Shooter ac/kapat (kostumun icinde)
 *  - Web Shooter ACIKKEN bos elle SAG TIKI BASILI TUT: ag at + sallan
 *    SHIFT basili ates et: web zip | SPACE: ipi birak ve firla
 */
@Mod(SpiderMod.MODID)
public class SpiderMod {
    public static final String MODID = "spidermod";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> SPIDER_SUIT = ITEMS.register("spider_suit",
            () -> new SpiderSuitItem(SuitMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));

    public SpiderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        bus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) {
            e.accept(SPIDER_SUIT);
        }
    }

    public static boolean wearingSuit(Player p) {
        return p.getItemBySlot(EquipmentSlot.CHEST).is(SPIDER_SUIT.get());
    }

    // ---------------- SUNUCU + ISTEMCI ----------------
    @Mod.EventBusSubscriber(modid = MODID)
    public static class CommonEvents {
        @SubscribeEvent
        public static void onFall(LivingFallEvent e) {
            if (e.getEntity() instanceof Player p && wearingSuit(p)) {
                e.setDamageMultiplier(0.25F);
            }
        }
    }

    // ---------------- ISTEMCI (MOD BUS) ----------------
    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            e.register(ClientEvents.WEB_KEY);
        }

        @SubscribeEvent
        public static void layerDefs(EntityRenderersEvent.RegisterLayerDefinitions e) {
            e.registerLayerDefinition(SpiderSuitLayer.WIDE, () -> SpiderSuitLayer.createLayer(false));
            e.registerLayerDefinition(SpiderSuitLayer.SLIM, () -> SpiderSuitLayer.createLayer(true));
        }

        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers e) {
            for (String skin : e.getSkins()) {
                PlayerRenderer r = e.getSkin(skin);
                if (r != null) r.addLayer(new SpiderSuitLayer(r, e.getEntityModels()));
            }
        }
    }

    // ---------------- ISTEMCI (FORGE BUS) ----------------
    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT)
    public static class ClientEvents {
        public static final KeyMapping WEB_KEY =
                new KeyMapping("key.spidermod.web_toggle", GLFW.GLFW_KEY_Y, "key.categories.spidermod");

        private static boolean webActive = false;
        private static Vec3 anchor = null;
        private static double ropeLen = 0;
        private static boolean zip = false;
        private static boolean fired = false;

        // duvara tirmanma modu
        private static boolean climbMode = false;
        private static Vec3 climbPush = Vec3.ZERO;
        private static int lostContact = 0;
        private static boolean prevJump = false;

        @SubscribeEvent
        public static void onTick(TickEvent.PlayerTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            if (!(e.player instanceof LocalPlayer p)) return;
            Minecraft mc = Minecraft.getInstance();

            boolean suit = wearingSuit(p);
            boolean jumpEdge = p.input.jumping && !prevJump; // SPACE'e yeni basildi
            prevJump = p.input.jumping;

            // Y tusu: web shooter ac/kapat
            while (WEB_KEY.consumeClick()) {
                if (!suit) {
                    p.displayClientMessage(Component.literal("§cOrumcek kostumunu giymelisin!"), true);
                } else {
                    webActive = !webActive;
                    p.displayClientMessage(Component.literal(
                            webActive ? "§aWeb Shooter: ACIK" : "§7Web Shooter: KAPALI"), true);
                }
            }
            if (!suit) webActive = false;

            boolean holding = webActive && mc.screen == null
                    && mc.options.keyUse.isDown()
                    && p.getMainHandItem().isEmpty();

            if (!holding || p.isDeadOrDying()) {
                anchor = null;
                fired = false;
            } else if (!fired) {
                fired = true;
                HitResult hit = p.pick(60.0D, 1.0F, false);
                if (hit.getType() == HitResult.Type.BLOCK) {
                    anchor = hit.getLocation();
                    zip = p.isShiftKeyDown();
                    ropeLen = Math.max(3.0D, anchor.distanceTo(p.getEyePosition()) * 0.85D);
                    p.swing(InteractionHand.MAIN_HAND);
                    p.level().playLocalSound(p.getX(), p.getY(), p.getZ(),
                            SoundEvents.FISHING_BOBBER_THROW, SoundSource.PLAYERS, 1.0F, 1.3F, false);
                }
            }

            // ---- SALLANMA / ZIP ----
            if (anchor != null) {
                climbMode = false;
                if (p.input.jumping) {
                    p.setDeltaMovement(p.getDeltaMovement().scale(1.2D).add(0, 0.3D, 0));
                    anchor = null;
                    return;
                }
                Vec3 eye = p.getEyePosition();
                Vec3 to = anchor.subtract(eye);
                double d = to.length();
                if (d < 2.0D) {
                    anchor = null;
                    return;
                }
                Vec3 dir = to.scale(1.0D / d);
                Vec3 v = p.getDeltaMovement();

                if (zip) {
                    v = v.scale(0.5D).add(dir.scale(0.7D));
                } else {
                    if (d > ropeLen) {
                        double radial = v.dot(dir);
                        if (radial < 0) v = v.subtract(dir.scale(radial));
                        v = v.add(dir.scale(Math.min(0.5D, (d - ropeLen) * 0.15D)));
                    }
                    if (p.input.forwardImpulse > 0) {
                        v = v.add(p.getLookAngle().scale(0.015D));
                    }
                }
                p.setDeltaMovement(v);
                p.fallDistance = 0;

                Vec3 start = eye.add(0, -0.3D, 0);
                Vec3 line = anchor.subtract(start);
                double len = line.length();
                Vec3 ld = line.normalize();
                for (double i = 0; i < len; i += 0.6D) {
                    Vec3 pt = start.add(ld.scale(i));
                    p.level().addParticle(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, 0, 0, 0);
                }
                return;
            }

            // ---- DUVAR TIRMANMA MODU ----
            // Ac: duvarin onunde EGILIRKEN ZIPLA (SHIFT + SPACE'e bir kez bas)
            // Modda: W = yukari, S = asagi, tus yok = duvarda asili kal
            // Kapat: SHIFT + SPACE (birak) | SPACE (duvardan siçra)
            boolean nearWall = !p.level().noCollision(p, p.getBoundingBox().inflate(0.2D, -0.1D, 0.2D));
            if (!suit || p.isInWater() || p.isDeadOrDying()) climbMode = false;

            if (climbMode) {
                if (jumpEdge) {
                    climbMode = false;
                    if (!p.isShiftKeyDown()) { // duvardan siçra
                        Vec3 look = p.getLookAngle();
                        p.setDeltaMovement(look.x * 0.6D, 0.6D, look.z * 0.6D);
                    }
                    return;
                }
                if (nearWall) lostContact = 0; else lostContact++;
                if (lostContact > 4) { // duvarin tepesine ulasildi / duvar bitti
                    climbMode = false;
                    return;
                }
                double vy = p.input.forwardImpulse > 0 ? 0.2D : (p.input.forwardImpulse < 0 ? -0.2D : 0.0D);
                if (vy < 0 && p.onGround()) { // asagi inip yere ulasti
                    climbMode = false;
                    return;
                }
                p.setDeltaMovement(climbPush.x, vy, climbPush.z);
                p.fallDistance = 0;
                return;
            }

            if (suit && jumpEdge && p.isShiftKeyDown() && nearWall && !p.isInWater()) {
                Direction d = p.getDirection();
                climbPush = new Vec3(d.getStepX() * 0.1D, 0, d.getStepZ() * 0.1D);
                climbMode = true;
                lostContact = 0;
                p.displayClientMessage(Component.literal("§aDuvara tirmanma: ACIK"), true);
            }
        }
    }
}
