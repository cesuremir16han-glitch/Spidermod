package com.example.spidermod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Istemci -> sunucu: Web Shooter acik mi ve hangi mod. Esyanin NBT'sine yazilir (herkese senkron, animasyon icin). */
public class SuitStatePacket {
    public final int webOn;
    public final int mode;

    public SuitStatePacket(int webOn, int mode) {
        this.webOn = webOn;
        this.mode = mode;
    }

    public static void encode(SuitStatePacket m, FriendlyByteBuf b) {
        b.writeByte(m.webOn);
        b.writeByte(m.mode);
    }

    public static SuitStatePacket decode(FriendlyByteBuf b) {
        return new SuitStatePacket(b.readByte(), b.readByte());
    }

    public static void handle(SuitStatePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp == null) return;
            ItemStack s = sp.getItemBySlot(EquipmentSlot.CHEST);
            if (!s.is(SpiderMod.SPIDER_SUIT.get())) return;
            s.getOrCreateTag().putBoolean("WebOn", m.webOn == 1);
            s.getOrCreateTag().putInt("WebMode", m.mode);
        });
        c.setPacketHandled(true);
    }
}
