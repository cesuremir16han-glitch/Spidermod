package com.example.spidermod;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SpiderMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, ToggleSuitPacket.class,
                ToggleSuitPacket::encode, ToggleSuitPacket::decode, ToggleSuitPacket::handle);
        CHANNEL.registerMessage(1, WebShotPacket.class,
                WebShotPacket::encode, WebShotPacket::decode, WebShotPacket::handle);
        CHANNEL.registerMessage(2, WebBoltPacket.class,
                WebBoltPacket::encode, WebBoltPacket::decode, WebBoltPacket::handle);
    }
}
