package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Doktor Oktopus kollari: pantolon takiliyken sirtta gorunur, H ile acilip kapanir. */
public class OctoArmsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "octo_arms"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderMod.MODID, "textures/entity/octo_arms.png");

    /** Oyuncu basina acilma ilerlemesi (0 kapali, 1 acik). SpiderMod her tick gunceller. */
    public static final Map<UUID, Float> OPEN = new HashMap<>();
    /** Yerel oyuncunun vurus animasyonu (10 -> 0). */
    public static int attackTicks = 0;

    private final OctoArmsModel model;

    public OctoArmsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent,
                         EntityModelSet models) {
        super(parent);
        this.model = new OctoArmsModel(models.bakeLayer(LAYER));
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (p.isInvisible() || !SpiderMod.wearingArms(p)) return;

        float open = OPEN.getOrDefault(p.getUUID(), 0F);
        float atk = p == Minecraft.getInstance().player ? Math.max(0F, attackTicks - partialTick) / 10F : 0F;

        pose.pushPose();
        getParentModel().body.translateAndRotate(pose);
        model.animate(open, ageInTicks, atk, SpiderMod.armsHolding(p));
        model.renderToBuffer(pose, buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)),
                light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        pose.popPose();
    }
}
