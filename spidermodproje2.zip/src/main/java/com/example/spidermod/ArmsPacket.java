package com.example.spidermod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Istemci -> sunucu: Doktor Oktopus kollari.
 * action 0 = kollari ac/kapat (H), 1 = kollarla vur (sol tik), 2 = yaratik tut / firlat (J),
 * 3 / 4 = havada asili kalma basladi / bitti (alt iki kol yere tutunur)
 */
public class ArmsPacket {
    public final int action;

    public ArmsPacket(int action) {
        this.action = action;
    }

    public static void encode(ArmsPacket m, FriendlyByteBuf b) {
        b.writeByte(m.action);
    }

    public static ArmsPacket decode(FriendlyByteBuf b) {
        return new ArmsPacket(b.readByte());
    }

    private static final Map<UUID, UUID> HELD = new HashMap<>();       // tutan oyuncu -> tutulan canli
    private static final Map<UUID, Long> LAST_ATTACK = new HashMap<>();

    public static void handle(ArmsPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp == null) return;
            ItemStack legs = sp.getItemBySlot(EquipmentSlot.LEGS);
            if (!legs.is(SpiderMod.OCTO_ARMS.get())) return;
            ServerLevel level = sp.serverLevel();
            switch (m.action) {
                case 0 -> toggle(sp, legs);
                case 1 -> {
                    if (SpiderMod.armsOpen(sp)) attack(sp, level);
                }
                case 2 -> {
                    if (SpiderMod.armsOpen(sp)) grab(sp, level, legs);
                }
                case 3 -> legs.getOrCreateTag().putBoolean("Perched", true);
                case 4 -> legs.getOrCreateTag().putBoolean("Perched", false);
                case 5 -> legs.getOrCreateTag().putBoolean("Climbing", true);
                case 6 -> legs.getOrCreateTag().putBoolean("Climbing", false);
                default -> { }
            }
        });
        c.setPacketHandled(true);
    }

    private static void toggle(ServerPlayer sp, ItemStack legs) {
        CompoundTag t = legs.getOrCreateTag();
        boolean open = !t.getBoolean("Open");
        t.putBoolean("Open", open);
        if (!open) {
            release(sp, false);
            t.putBoolean("Perched", false);
            t.putBoolean("Climbing", false);
        }
        sp.level().playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                SoundEvents.PISTON_EXTEND, SoundSource.PLAYERS, 0.8F, open ? 1.2F : 0.8F);
        sp.displayClientMessage(Component.literal(open ? "§6Oktopus kollari: ACIK" : "§7Oktopus kollari: KAPALI"), true);
    }

    private static final Map<UUID, Long> STRIKE_END = new HashMap<>();

    /** Vurus animasyonu isaretini kisa sure sonra kaldirir. */
    public static void tickStrikes(MinecraftServer server) {
        if (STRIKE_END.isEmpty() || server == null) return;
        for (Map.Entry<UUID, Long> en : new ArrayList<>(STRIKE_END.entrySet())) {
            ServerPlayer h = server.getPlayerList().getPlayer(en.getKey());
            if (h == null) {
                STRIKE_END.remove(en.getKey());
                continue;
            }
            if (h.level().getGameTime() >= en.getValue()) {
                ItemStack lg = h.getItemBySlot(EquipmentSlot.LEGS);
                if (lg.hasTag()) lg.getTag().putBoolean("Strike", false);
                STRIKE_END.remove(en.getKey());
            }
        }
    }

    private static EntityHitResult target(ServerPlayer sp, ServerLevel level, boolean includePlayers, UUID ignore) {
        Vec3 eye = sp.getEyePosition();
        Vec3 end = eye.add(sp.getLookAngle().normalize().scale(7.0D));
        BlockHitResult b = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        if (b.getType() == HitResult.Type.BLOCK) end = b.getLocation();
        return ProjectileUtil.getEntityHitResult(level, sp, eye, end, new AABB(eye, end).inflate(1.5D),
                en -> en instanceof LivingEntity && en != sp && !en.isSpectator() && en.isPickable()
                        && (includePlayers || !(en instanceof Player)) && !en.getUUID().equals(ignore));
    }

    // ---------- KOLLARLA VURUS ----------
    private static void attack(ServerPlayer sp, ServerLevel level) {
        long now = level.getGameTime();
        Long last = LAST_ATTACK.get(sp.getUUID());
        if (last != null && now - last < 10L) return;
        LAST_ATTACK.put(sp.getUUID(), now);
        ItemStack lg = sp.getItemBySlot(EquipmentSlot.LEGS);
        if (lg.is(SpiderMod.OCTO_ARMS.get())) lg.getOrCreateTag().putBoolean("Strike", true); // GeckoLib "attack" animasyonu
        STRIKE_END.put(sp.getUUID(), now + 8L);

        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 0.8F);
        EntityHitResult ehr = target(sp, level, true, HELD.get(sp.getUUID()));
        if (ehr == null) return;
        Entity t = ehr.getEntity();
        t.hurt(level.damageSources().playerAttack(sp), 9.0F);
        if (t instanceof LivingEntity le) {
            Vec3 look = sp.getLookAngle();
            le.knockback(1.0D, -look.x, -look.z);
        }
    }

    // ---------- TUT / FIRLAT ----------
    private static void grab(ServerPlayer sp, ServerLevel level, ItemStack legs) {
        if (HELD.containsKey(sp.getUUID())) {
            release(sp, true);
            sp.displayClientMessage(Component.literal("§7Firlatildi!"), true);
            return;
        }
        EntityHitResult ehr = target(sp, level, false, null);
        if (ehr == null) {
            sp.displayClientMessage(Component.literal("§cYakinda tutulacak canli yok!"), true);
            return;
        }
        HELD.put(sp.getUUID(), ehr.getEntity().getUUID());
        legs.getOrCreateTag().putBoolean("Holding", true);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 1.0F, 0.8F);
        sp.displayClientMessage(Component.literal("§6Yaratik tutuldu! (J: firlat)"), true);
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel lv : server.getAllLevels()) {
            Entity en = lv.getEntity(id);
            if (en != null) return en;
        }
        return null;
    }

    private static void release(ServerPlayer sp, boolean throwIt) {
        UUID id = HELD.remove(sp.getUUID());
        ItemStack legs = sp.getItemBySlot(EquipmentSlot.LEGS);
        if (legs.is(SpiderMod.OCTO_ARMS.get())) legs.getOrCreateTag().putBoolean("Holding", false);
        if (id == null || sp.getServer() == null) return;
        Entity en = find(sp.getServer(), id);
        if (en != null && throwIt) {
            Vec3 look = sp.getLookAngle();
            en.setDeltaMovement(look.scale(1.4D).add(0, 0.2D, 0));
            en.hurtMarked = true;
        }
    }

    /** Sunucu tickinde: tutulan canlilari tutanin onunde havada tutar. */
    public static void tickHeld(MinecraftServer server) {
        if (HELD.isEmpty() || server == null) return;
        for (Map.Entry<UUID, UUID> en : new ArrayList<>(HELD.entrySet())) {
            ServerPlayer h = server.getPlayerList().getPlayer(en.getKey());
            if (h == null) {
                HELD.remove(en.getKey());
                continue;
            }
            if (!h.isAlive() || !SpiderMod.armsOpen(h)) {
                release(h, false);
                continue;
            }
            Entity target = find(server, en.getValue());
            if (target == null || !target.isAlive()) {
                release(h, false);
                continue;
            }
            Vec3 pos = h.getEyePosition().add(h.getLookAngle().scale(3.0D)).add(0, -0.8D, 0);
            target.moveTo(pos.x, pos.y, pos.z, target.getYRot(), target.getXRot());
            target.setDeltaMovement(Vec3.ZERO);
            target.fallDistance = 0;
            target.hurtMarked = true;
        }
    }
}
