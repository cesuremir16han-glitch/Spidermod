package com.example.spidermod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

public enum SuitMaterial implements ArmorMaterial {
    INSTANCE;

    @Override public int getDurabilityForType(ArmorItem.Type type) { return 5000; }
    @Override public int getDefenseForType(ArmorItem.Type type) { return type == ArmorItem.Type.CHESTPLATE ? 22 : 8; }
    @Override public int getEnchantmentValue() { return 25; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.STRING); }
    @Override public String getName() { return SpiderMod.MODID + ":spider_suit"; }
    @Override public float getToughness() { return 12.0F; }
    @Override public float getKnockbackResistance() { return 0.4F; }
}
