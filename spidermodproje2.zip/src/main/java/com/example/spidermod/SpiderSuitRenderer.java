package com.example.spidermod;

import software.bernie.geckolib.renderer.GeoArmorRenderer;

/** Orumcek Adam kostumu icin GeckoLib zirh cizici. */
public class SpiderSuitRenderer extends GeoArmorRenderer<SpiderSuitItem> {
    public SpiderSuitRenderer() {
        super(new SpiderSuitGeoModel());
    }
}
