package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/** Orumcek Adam kostumu: tum vucut katmani. G ile maske (suit basi) acilip kapanir. */
public class SpiderSuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation WIDE =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "suit_wide"), "main");
    public static final ModelLayerLocation SLIM =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "suit_slim"), "main");
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderMod.MODID, "textures/entity/spider_suit.png");

    /** Birinci sahis kol cizimi icin (SpiderMod.onArm). */
    public static PlayerModel<AbstractClientPlayer> fpWide;
    public static PlayerModel<AbstractClientPlayer> fpSlim;

    private final PlayerModel<AbstractClientPlayer> wide;
    private final PlayerModel<AbstractClientPlayer> slim;

    public SpiderSuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent,
                           EntityModelSet models) {
        super(parent);
        this.wide = new PlayerModel<>(models.bakeLayer(WIDE), false);
        this.slim = new PlayerModel<>(models.bakeLayer(SLIM), true);
        fpWide = new PlayerModel<>(models.bakeLayer(WIDE), false);
        fpSlim = new PlayerModel<>(models.bakeLayer(SLIM), true);
    }

    public static LayerDefinition createLayer(boolean slim) {
        return LayerDefinition.create(PlayerModel.createMesh(new CubeDeformation(0.35F), slim), 64, 64);
    }

    /** Kostum tam giyili mi (eskiden nano animasyonu icindi, artik hemen). */
    public static boolean fullyWorn(Player p) {
        return true;
    }

    /** Sallanma / tirmanma pozlari: ayaklar ve kollar oynar. */
    private static void applyPose(PlayerModel<AbstractClientPlayer> m, int mode, float t) {
        float s = Mth.sin(t * 0.35F);
        switch (mode) {
            case 1 -> { // sallanma: sag kol aga uzanir, ayaklar pedal cevirir
                m.rightArm.xRot = -3.0F; m.rightArm.yRot = 0F; m.rightArm.zRot = -0.15F;
                m.leftArm.xRot = 0.5F + Mth.sin(t * 0.2F) * 0.3F; m.leftArm.zRot = 0.3F;
                m.rightLeg.xRot = s * 0.8F - 0.3F; m.leftLeg.xRot = -s * 0.8F - 0.3F;
            }
            case 2 -> { // zip: kollar onde, bacaklar arkada
                m.rightArm.xRot = -1.7F; m.leftArm.xRot = -1.7F;
                m.rightArm.yRot = 0F; m.leftArm.yRot = 0F;
                m.rightLeg.xRot = 0.5F + s * 0.1F; m.leftLeg.xRot = 0.5F - s * 0.1F;
            }
            default -> { // duvar / tavan: kollar ve ayaklar sirayla hareket eder
                float w = SpiderMod.ClientEvents.climbMoving() ? Mth.sin(t * 0.4F) : 0F;
                m.rightArm.xRot = -2.6F + w * 0.35F; m.leftArm.xRot = -2.6F - w * 0.35F;
                m.rightArm.yRot = 0F; m.leftArm.yRot = 0F;
                m.rightArm.zRot = -0.25F; m.leftArm.zRot = 0.25F;
                m.rightLeg.xRot = -0.35F + w * 0.45F; m.leftLeg.xRot = -0.35F - w * 0.45F;
                m.head.xRot = -0.7F; m.head.yRot = 0F; m.head.zRot = 0F; // ucar gibi ileri bak
            }
        }
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (p.isInvisible() || !SpiderMod.wearingSuit(p)) return;

        PlayerModel<AbstractClientPlayer> m = "slim".equals(p.getModelName()) ? slim : wide;
        getParentModel().copyPropertiesTo(m);
        m.setAllVisible(true);
        m.head.visible = !SpiderMod.maskOff(p); // maske acikken kendi yuzun gorunur
        m.hat.visible = false;
        m.jacket.visible = false;
        m.leftSleeve.visible = false;
        m.rightSleeve.visible = false;
        m.leftPants.visible = false;
        m.rightPants.visible = false;

        if (p == Minecraft.getInstance().player) {
            int mode = SpiderMod.ClientEvents.poseMode();
            if (mode != 0) applyPose(m, mode, ageInTicks);
        }

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        m.renderToBuffer(pose, vc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
