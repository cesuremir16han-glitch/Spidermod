package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Kostum aktifken bas, govde, kollar, bacaklar + sirtta Iron Spider bacaklari. */
public class SpiderSuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation WIDE =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "suit_wide"), "main");
    public static final ModelLayerLocation SLIM =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "suit_slim"), "main");
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderMod.MODID, "textures/entity/spider_suit.png");

    /** Birinci sahis kol cizimi icin (RenderArmEvent) paylasilan modeller. */
    public static PlayerModel<AbstractClientPlayer> fpWide;
    public static PlayerModel<AbstractClientPlayer> fpSlim;

    private final PlayerModel<AbstractClientPlayer> wide;
    private final PlayerModel<AbstractClientPlayer> slim;
    private final IronLegsModel legs;

    public SpiderSuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent,
                           EntityModelSet models) {
        super(parent);
        this.wide = new PlayerModel<>(models.bakeLayer(WIDE), false);
        this.slim = new PlayerModel<>(models.bakeLayer(SLIM), true);
        this.legs = new IronLegsModel(models.bakeLayer(IronLegsModel.LAYER));
        fpWide = this.wide;
        fpSlim = this.slim;
    }

    public static LayerDefinition createLayer(boolean slim) {
        return LayerDefinition.create(PlayerModel.createMesh(new CubeDeformation(0.35F), slim), 64, 64);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (p.isInvisible() || !SpiderMod.wearingSuit(p)) return;

        PlayerModel<AbstractClientPlayer> m = "slim".equals(p.getModelName()) ? slim : wide;
        getParentModel().copyPropertiesTo(m);
        m.setAllVisible(true);
        m.hat.visible = false;
        m.jacket.visible = false;
        m.leftSleeve.visible = false;
        m.rightSleeve.visible = false;
        m.leftPants.visible = false;
        m.rightPants.visible = false;

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        m.renderToBuffer(pose, vc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);

        // Iron Spider mekanik bacaklari (govdeye bagli)
        pose.pushPose();
        getParentModel().body.translateAndRotate(pose);
        legs.animate(ageInTicks);
        legs.renderToBuffer(pose, buffer.getBuffer(RenderType.entityCutoutNoCull(IronLegsModel.TEXTURE)),
                light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        pose.popPose();
    }
}
