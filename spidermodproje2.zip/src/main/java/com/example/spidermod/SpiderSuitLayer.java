package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Iron Spider: tum vucut katmani + sirtta 4 mekanik bacak. Giyilince nano gibi yavasca belirir. */
public class SpiderSuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation WIDE =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "suit_wide"), "main");
    public static final ModelLayerLocation SLIM =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "suit_slim"), "main");
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderMod.MODID, "textures/entity/spider_suit.png");

    /** Birinci sahis kol cizimi icin (SpiderMod.onArm). */
    public static PlayerModel<AbstractClientPlayer> fpWide;
    public static PlayerModel<AbstractClientPlayer> fpSlim;

    /** Oyuncunun kostumu giydigi oyun zamani (belirme animasyonu icin). SpiderMod temizler. */
    public static final Map<UUID, Long> WORN_SINCE = new HashMap<>();

    private static final float FADE_TICKS = 12.0F;

    private final PlayerModel<AbstractClientPlayer> wide;
    private final PlayerModel<AbstractClientPlayer> slim;
    private final IronLegsModel legs;

    public SpiderSuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent,
                           EntityModelSet models) {
        super(parent);
        this.wide = new PlayerModel<>(models.bakeLayer(WIDE), false);
        this.slim = new PlayerModel<>(models.bakeLayer(SLIM), true);
        this.legs = new IronLegsModel(models.bakeLayer(IronLegsModel.LAYER));
        fpWide = new PlayerModel<>(models.bakeLayer(WIDE), false);
        fpSlim = new PlayerModel<>(models.bakeLayer(SLIM), true);
    }

    public static LayerDefinition createLayer(boolean slim) {
        return LayerDefinition.create(PlayerModel.createMesh(new CubeDeformation(0.35F), slim), 64, 64);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffer, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (p.isInvisible() || !SpiderMod.wearingSuit(p)) return;

        long now = p.level().getGameTime();
        long since = WORN_SINCE.computeIfAbsent(p.getUUID(), k -> now);
        float progress = Math.min(1.0F, ((now - since) + partialTick) / FADE_TICKS);
        boolean fading = progress < 1.0F;

        PlayerModel<AbstractClientPlayer> m = "slim".equals(p.getModelName()) ? slim : wide;
        getParentModel().copyPropertiesTo(m);
        m.setAllVisible(true);
        m.hat.visible = false;
        m.jacket.visible = false;
        m.leftSleeve.visible = false;
        m.rightSleeve.visible = false;
        m.leftPants.visible = false;
        m.rightPants.visible = false;

        VertexConsumer vc = buffer.getBuffer(fading
                ? RenderType.entityTranslucent(TEXTURE) : RenderType.entityCutoutNoCull(TEXTURE));
        m.renderToBuffer(pose, vc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, progress);

        // sirtta mekanik bacaklar (govdeyle birlikte hareket eder)
        pose.pushPose();
        getParentModel().body.translateAndRotate(pose);
        legs.animate(ageInTicks);
        VertexConsumer lvc = buffer.getBuffer(fading
                ? RenderType.entityTranslucent(IronLegsModel.TEXTURE) : RenderType.entityCutoutNoCull(IronLegsModel.TEXTURE));
        legs.renderToBuffer(pose, lvc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, progress);
        pose.popPose();
    }
}
