package com.example.spidermod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Sunucu -> istemci: atilan agin cizgi noktalari (gorsel icin). */
public class WebBoltPacket {
    public final List<Vec3> pts;
    public final int mode;

    public WebBoltPacket(List<Vec3> pts, int mode) {
        this.pts = pts;
        this.mode = mode;
    }

    public static void encode(WebBoltPacket m, FriendlyByteBuf b) {
        b.writeByte(m.mode);
        b.writeVarInt(m.pts.size());
        for (Vec3 v : m.pts) {
            b.writeDouble(v.x);
            b.writeDouble(v.y);
            b.writeDouble(v.z);
        }
    }

    public static WebBoltPacket decode(FriendlyByteBuf b) {
        int mode = b.readByte();
        int n = b.readVarInt();
        List<Vec3> pts = new ArrayList<>();
        for (int i = 0; i < n; i++) pts.add(new Vec3(b.readDouble(), b.readDouble(), b.readDouble()));
        return new WebBoltPacket(pts, mode);
    }

    public static void handle(WebBoltPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> SpiderMod.ClientEvents.addBolt(m.pts, m.mode)));
        c.setPacketHandled(true);
    }
}
