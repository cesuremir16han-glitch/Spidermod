package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;

/** Sirtta 4 mekanik kol; her kol 4 parca (omuz, dirsek, bilek, pence). */
public class OctoArmsModel extends Model {
    private final ModelPart root;
    private final ModelPart[][] seg = new ModelPart[4][4];

    public OctoArmsModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        for (int i = 0; i < 4; i++) {
            ModelPart a = root.getChild("arm" + i);
            seg[i][0] = a;
            seg[i][1] = a.getChild("s1");
            seg[i][2] = seg[i][1].getChild("s2");
            seg[i][3] = seg[i][2].getChild("s3");
        }
    }

    public static LayerDefinition createLayer() {
        MeshDefinition md = new MeshDefinition();
        PartDefinition r = md.getRoot();
        for (int i = 0; i < 4; i++) {
            float side = i < 2 ? -1F : 1F;
            int level = i % 2;
            PartDefinition a = r.addOrReplaceChild("arm" + i,
                    CubeListBuilder.create().texOffs(0, 0).addBox(-1F, -1F, 0F, 2F, 2F, 9F),
                    PartPose.offset(side * 2.5F, 2.0F + level * 5.0F, 2.5F));
            PartDefinition s1 = a.addOrReplaceChild("s1",
                    CubeListBuilder.create().texOffs(0, 0).addBox(-1F, -1F, 0F, 2F, 2F, 9F),
                    PartPose.offset(0F, 0F, 9F));
            PartDefinition s2 = s1.addOrReplaceChild("s2",
                    CubeListBuilder.create().texOffs(0, 0).addBox(-1F, -1F, 0F, 2F, 2F, 9F),
                    PartPose.offset(0F, 0F, 9F));
            s2.addOrReplaceChild("s3",
                    CubeListBuilder.create().texOffs(0, 12).addBox(-1.5F, -1.5F, 0F, 3F, 3F, 4F),
                    PartPose.offset(0F, 0F, 9F));
        }
        return LayerDefinition.create(md, 32, 32);
    }

    /** open: 0 kapali -> 1 acik; atk: 1 -> 0 (vurus animasyonu); holding: yaratik tutuluyor. */
    public void animate(float open, float t, float atk, boolean holding) {
        float sf = atk > 0F ? Mth.sin((1F - atk) * Mth.PI) : 0F;
        for (int i = 0; i < 4; i++) {
            float side = i < 2 ? -1F : 1F;
            int level = i % 2;
            float w1 = Mth.sin(t * 0.10F + i * 1.7F);
            float w2 = Mth.sin(t * 0.13F + i * 1.1F + 1F);

            // kapali: sirta katlanmis
            float cx = -1.25F - level * 0.2F, cy = side * 0.25F, c1 = 0.5F, c2 = 0.5F, c3 = 0.6F;
            // acik: omuz ustunden yanlara yayilir, hafifce dalgalanir
            float ox = 0.5F - level * 0.15F, oy = side * (0.6F + level * 0.5F);
            float o1 = -0.4F + w1 * 0.15F, o2 = -0.5F + w2 * 0.2F, o3 = -0.6F + w1 * 0.2F;
            if (holding) { // yaratigi onde tutmak icin one uzanir
                ox = -0.4F; oy = side * (2.5F - level * 0.15F);
                o1 = 0.35F + w1 * 0.05F; o2 = 0.3F; o3 = 0.3F;
            }
            if (atk > 0F && level == 0) { // ust cift omuz ustunden one kamcilanir
                ox = Mth.lerp(sf, ox, 1.3F);
                oy = Mth.lerp(sf, oy, side * 0.25F);
                o1 = Mth.lerp(sf, o1, -2.1F);
                o2 = Mth.lerp(sf, o2, -0.6F);
            }
            seg[i][0].xRot = Mth.lerp(open, cx, ox);
            seg[i][0].yRot = Mth.lerp(open, cy, oy);
            seg[i][1].xRot = Mth.lerp(open, c1, o1);
            seg[i][2].xRot = Mth.lerp(open, c2, o2);
            seg[i][3].xRot = Mth.lerp(open, c3, o3);
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vc, int light, int overlay,
                               float r, float g, float b, float a) {
        root.render(pose, vc, light, overlay, r, g, b, a);
    }
}
