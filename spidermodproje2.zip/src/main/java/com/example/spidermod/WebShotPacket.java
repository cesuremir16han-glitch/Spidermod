package com.example.spidermod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Istemci -> sunucu: ag atisi.
 * mode 1 = SEKEN AG (duvarlardan sekerek ilerler, vurdugu canliya hasar + yavaslik)
 * mode 2 = YAPISTIRICI AG (canliyi yerine yapistirir, bloga orumcek agi koyar)
 * mode 3 = KOPRU AGI (1. atis ilk noktayi, 2. atis ikinci noktayi secer; arasina yurunebilir ag gerilir)
 */
public class WebShotPacket {
    public final int mode;

    public WebShotPacket(int mode) {
        this.mode = mode;
    }

    public static void encode(WebShotPacket m, FriendlyByteBuf b) {
        b.writeByte(m.mode);
    }

    public static WebShotPacket decode(FriendlyByteBuf b) {
        return new WebShotPacket(b.readByte());
    }

    private static final Map<UUID, Long> LAST = new HashMap<>();
    private static final List<Object[]> TEMP_WEBS = new ArrayList<>(); // {ServerLevel, BlockPos, Long bitisZamani}

    public static void handle(WebShotPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp == null || !SpiderMod.wearingSuit(sp)) return;
            ServerLevel level = sp.serverLevel();
            long now = level.getGameTime();
            Long last = LAST.get(sp.getUUID());
            if (last != null && now - last < 8L) return; // bekleme suresi
            LAST.put(sp.getUUID(), now);

            if (m.mode == 1) bounce(sp, level);
            else if (m.mode == 2) sticky(sp, level);
            else if (m.mode == 3) bridge(sp, level);
        });
        c.setPacketHandled(true);
    }

    // ---------- SEKEN AG ----------
    private static void bounce(ServerPlayer sp, ServerLevel level) {
        List<Vec3> pts = new ArrayList<>();
        Vec3 pos = sp.getEyePosition();
        Vec3 dir = sp.getLookAngle().normalize();
        pts.add(pos);
        double remaining = 48.0D;

        for (int b = 0; b <= 3 && remaining > 0.5D; b++) {
            Vec3 end = pos.add(dir.scale(remaining));
            BlockHitResult bhr = level.clip(new ClipContext(pos, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
            boolean hitBlock = bhr.getType() == HitResult.Type.BLOCK;
            Vec3 segEnd = hitBlock ? bhr.getLocation() : end;

            EntityHitResult ehr = findEntity(sp, level, pos, segEnd);
            if (ehr != null) {
                Entity t = ehr.getEntity();
                pts.add(ehr.getLocation());
                t.hurt(level.damageSources().playerAttack(sp), 5.0F);
                if (t instanceof LivingEntity le) {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                }
                break;
            }
            pts.add(segEnd);
            remaining -= pos.distanceTo(segEnd);
            if (!hitBlock) break;

            // yansima: yuzey normaline gore yon degistir
            Vec3 n = Vec3.atLowerCornerOf(bhr.getDirection().getNormal());
            dir = dir.subtract(n.scale(2.0D * dir.dot(n))).normalize();
            pos = segEnd.add(n.scale(0.02D));
        }
        send(sp, pts, 1);
    }

    // ---------- YAPISTIRICI AG ----------
    private static void sticky(ServerPlayer sp, ServerLevel level) {
        List<Vec3> pts = new ArrayList<>();
        Vec3 pos = sp.getEyePosition();
        Vec3 end = pos.add(sp.getLookAngle().normalize().scale(48.0D));
        pts.add(pos);

        BlockHitResult bhr = level.clip(new ClipContext(pos, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        boolean hitBlock = bhr.getType() == HitResult.Type.BLOCK;
        Vec3 segEnd = hitBlock ? bhr.getLocation() : end;

        EntityHitResult ehr = findEntity(sp, level, pos, segEnd);
        if (ehr != null) {
            Entity t = ehr.getEntity();
            pts.add(ehr.getLocation());
            if (t instanceof LivingEntity le) {
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 6)); // yerinde kal
                le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
            }
            placeWeb(level, BlockPos.containing(t.getX(), t.getY(), t.getZ()));
        } else {
            pts.add(segEnd);
            if (hitBlock) placeWeb(level, bhr.getBlockPos().relative(bhr.getDirection()));
        }
        send(sp, pts, 2);
    }

    // ---------- KOPRU AGI ----------
    private static final Map<UUID, Object[]> BRIDGE_START = new HashMap<>(); // {ServerLevel, Vec3 hit, BlockPos hava, Long zaman}

    private static void bridge(ServerPlayer sp, ServerLevel level) {
        Vec3 pos = sp.getEyePosition();
        Vec3 end = pos.add(sp.getLookAngle().normalize().scale(48.0D));
        BlockHitResult bhr = level.clip(new ClipContext(pos, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        if (bhr.getType() != HitResult.Type.BLOCK) {
            sp.displayClientMessage(Component.literal("§cBir duvara bakmalisin!"), true);
            return;
        }
        Vec3 hit = bhr.getLocation();
        BlockPos air = bhr.getBlockPos().relative(bhr.getDirection());
        List<Vec3> pts = new ArrayList<>();
        pts.add(pos);
        pts.add(hit);

        Object[] st = BRIDGE_START.get(sp.getUUID());
        long now = level.getGameTime();
        if (st == null || st[0] != level || now - (Long) st[3] > 600L) {
            BRIDGE_START.put(sp.getUUID(), new Object[]{level, hit, air, now});
            sp.displayClientMessage(Component.literal("§b1. nokta secildi! Simdi karsi duvara at."), true);
            send(sp, pts, 3);
            return;
        }

        BRIDGE_START.remove(sp.getUUID());
        BlockPos a = (BlockPos) st[2];
        if (Math.sqrt(a.distSqr(air)) > 40.0D) {
            sp.displayClientMessage(Component.literal("§cCok uzak! (en fazla 40 blok)"), true);
            return;
        }
        buildBridge(level, a, air);
        pts.add((Vec3) st[1]); // ag cizgisi iki nokta arasini da gosterir
        sp.displayClientMessage(Component.literal("§aKopru hazir! (15 sn)"), true);
        send(sp, pts, 3);
    }

    /** a ile b arasinda yan yana bitisik (kose kose degil) ag bloklari dizer. */
    private static void buildBridge(ServerLevel level, BlockPos a, BlockPos b) {
        Vec3 va = Vec3.atCenterOf(a);
        Vec3 vb = Vec3.atCenterOf(b);
        int steps = (int) Math.ceil(va.distanceTo(vb) * 4.0D);
        Set<BlockPos> done = new HashSet<>();
        BlockPos prev = a;
        placeBridge(level, a, done);
        for (int i = 1; i <= steps; i++) {
            BlockPos target = BlockPos.containing(va.lerp(vb, i / (double) steps));
            BlockPos cur = prev;
            while (!cur.equals(target)) { // once x, sonra z, sonra y: hep yuzey komsulugu
                if (cur.getX() != target.getX()) cur = cur.offset(Integer.signum(target.getX() - cur.getX()), 0, 0);
                else if (cur.getZ() != target.getZ()) cur = cur.offset(0, 0, Integer.signum(target.getZ() - cur.getZ()));
                else cur = cur.offset(0, Integer.signum(target.getY() - cur.getY()), 0);
                placeBridge(level, cur, done);
            }
            prev = target;
        }
    }

    private static void placeBridge(ServerLevel level, BlockPos pos, Set<BlockPos> done) {
        if (!done.add(pos)) return;
        BlockState st = level.getBlockState(pos);
        if (st.isAir() || st.canBeReplaced()) {
            level.setBlock(pos, SpiderMod.WEB_BRIDGE.get().defaultBlockState(), 3);
            level.scheduleTick(pos, SpiderMod.WEB_BRIDGE.get(), 300); // 15 sn sonra kalkar
        }
    }

    private static EntityHitResult findEntity(ServerPlayer sp, ServerLevel level, Vec3 a, Vec3 b) {
        return ProjectileUtil.getEntityHitResult(level, sp, a, b, new AABB(a, b).inflate(1.0D),
                en -> en instanceof LivingEntity && en != sp && !en.isSpectator() && en.isPickable());
    }

    private static void placeWeb(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.isAir() || st.canBeReplaced()) {
            level.setBlockAndUpdate(pos, Blocks.COBWEB.defaultBlockState());
            TEMP_WEBS.add(new Object[]{level, pos.immutable(), level.getGameTime() + 400L}); // 20 sn sonra kalkar
        }
    }

    /** Sunucu tickinde cagrilir: sure dolan ag bloklarini kaldirir. */
    public static void tickTempWebs() {
        if (TEMP_WEBS.isEmpty()) return;
        Iterator<Object[]> it = TEMP_WEBS.iterator();
        while (it.hasNext()) {
            Object[] o = it.next();
            ServerLevel lv = (ServerLevel) o[0];
            BlockPos bp = (BlockPos) o[1];
            long exp = (Long) o[2];
            if (lv.getGameTime() >= exp) {
                if (lv.getBlockState(bp).is(Blocks.COBWEB)) lv.removeBlock(bp, false);
                it.remove();
            }
        }
    }

    private static void send(ServerPlayer sp, List<Vec3> pts, int mode) {
        Net.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp), new WebBoltPacket(pts, mode));
        sp.level().playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                SoundEvents.FISHING_BOBBER_THROW, SoundSource.PLAYERS, 1.0F, 1.3F);
    }
}
