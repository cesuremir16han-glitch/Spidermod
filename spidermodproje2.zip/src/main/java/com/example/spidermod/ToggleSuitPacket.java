package com.example.spidermod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;
import org.joml.Vector3f;

import java.util.List;
import java.util.function.Supplier;

/**
 * Istemci -> sunucu: G tusu. Kostum envanterdeyse nano efektiyle vucuda gecer (gogus slotuna),
 * giyiliyse cikarilip envantere geri doner.
 */
public class ToggleSuitPacket {
    public ToggleSuitPacket() {}

    public static void encode(ToggleSuitPacket m, FriendlyByteBuf b) {}

    public static ToggleSuitPacket decode(FriendlyByteBuf b) {
        return new ToggleSuitPacket();
    }

    public static void handle(ToggleSuitPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp == null) return;

            ItemStack chest = sp.getItemBySlot(EquipmentSlot.CHEST);
            if (chest.is(SpiderMod.SPIDER_SUIT.get())) {
                // cikar -> envantere ver
                sp.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                if (!sp.getInventory().add(chest)) sp.drop(chest, false);
                nano(sp, false);
                sp.displayClientMessage(Component.literal("§7Nano kostum: KAPALI"), true);
                return;
            }

            // giy -> envanterde kostum ara
            List<ItemStack> items = sp.getInventory().items;
            int slot = -1;
            for (int i = 0; i < items.size(); i++) {
                if (items.get(i).is(SpiderMod.SPIDER_SUIT.get())) { slot = i; break; }
            }
            if (slot < 0) {
                sp.displayClientMessage(Component.literal("§cEnvanterinde Iron Spider kostumu yok!"), true);
                return;
            }
            ItemStack suit = items.get(slot);
            items.set(slot, chest); // eski gogusluk (varsa) envantere gecer
            sp.setItemSlot(EquipmentSlot.CHEST, suit);
            nano(sp, true);
            sp.displayClientMessage(Component.literal("§6Nano kostum: AKTIF"), true);
        });
        c.setPacketHandled(true);
    }

    /** Kirmizi-altin nano parcacik patlamasi + ses. */
    private static void nano(ServerPlayer sp, boolean on) {
        if (!(sp.level() instanceof ServerLevel lvl)) return;
        lvl.sendParticles(new DustParticleOptions(new Vector3f(0.75F, 0.1F, 0.12F), 1.2F),
                sp.getX(), sp.getY() + 0.9D, sp.getZ(), 40, 0.5D, 0.9D, 0.5D, 0.05D);
        lvl.sendParticles(new DustParticleOptions(new Vector3f(0.95F, 0.72F, 0.2F), 1.2F),
                sp.getX(), sp.getY() + 0.9D, sp.getZ(), 40, 0.5D, 0.9D, 0.5D, 0.05D);
        lvl.playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                on ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE,
                SoundSource.PLAYERS, 0.8F, 1.6F);
        lvl.playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                SoundEvents.ARMOR_EQUIP_NETHERITE, SoundSource.PLAYERS, 0.8F, 1.2F);
    }
}
