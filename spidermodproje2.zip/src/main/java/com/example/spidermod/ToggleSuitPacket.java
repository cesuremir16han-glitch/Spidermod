package com.example.spidermod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** NANO KOSTUM: tusa basinca kostum envanterden vucuda (ya da geri) gecer. */
public class ToggleSuitPacket {
    public ToggleSuitPacket() {}

    public static void encode(ToggleSuitPacket m, FriendlyByteBuf b) {}

    public static ToggleSuitPacket decode(FriendlyByteBuf b) {
        return new ToggleSuitPacket();
    }

    public static void handle(ToggleSuitPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) toggle(p);
        });
        ctx.get().setPacketHandled(true);
    }

    private static void toggle(ServerPlayer p) {
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        Inventory inv = p.getInventory();

        if (chest.is(SpiderMod.SPIDER_SUIT.get())) { // nano kostumu coz
            ItemStack copy = chest.copy();
            if (inv.add(copy)) {
                p.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                fx(p, false);
                p.displayClientMessage(Component.literal("§7Nano kostum cozuldu"), true);
            } else {
                p.displayClientMessage(Component.literal("§cEnvanter dolu!"), true);
            }
            return;
        }

        for (int i = 0; i < inv.items.size(); i++) { // nano kostumu giy
            ItemStack s = inv.items.get(i);
            if (s.is(SpiderMod.SPIDER_SUIT.get())) {
                ItemStack old = chest.copy();
                p.setItemSlot(EquipmentSlot.CHEST, s.copy());
                inv.items.set(i, old); // eski gogusluk bos slota gecer
                fx(p, true);
                p.displayClientMessage(Component.literal("§cIron Spider §6nano kostum aktif!"), true);
                return;
            }
        }
        p.displayClientMessage(Component.literal("§cEnvanterinde nano kostum yok!"), true);
    }

    private static void fx(ServerPlayer p, boolean on) {
        ServerLevel l = p.serverLevel();
        l.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 0.9D, p.getZ(), 60, 0.35D, 0.9D, 0.35D, 0.2D);
        l.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 0.9D, p.getZ(), 25, 0.3D, 0.9D, 0.3D, 0.03D);
        l.playSound(null, p.getX(), p.getY(), p.getZ(),
                on ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE,
                SoundSource.PLAYERS, 0.8F, 1.8F);
    }
}
