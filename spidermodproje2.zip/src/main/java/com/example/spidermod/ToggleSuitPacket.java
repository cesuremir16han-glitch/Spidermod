package com.example.spidermod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Istemci -> sunucu: G tusu. Kostumun maskesini acar/kapatir. Durum esyanin NBT'sinde ("MaskOff") tutulur, herkese senkron olur. */
public class ToggleSuitPacket {
    public ToggleSuitPacket() {}

    public static void encode(ToggleSuitPacket m, FriendlyByteBuf b) {}

    public static ToggleSuitPacket decode(FriendlyByteBuf b) {
        return new ToggleSuitPacket();
    }

    public static void handle(ToggleSuitPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp == null) return;
            ItemStack s = sp.getItemBySlot(EquipmentSlot.CHEST);
            if (!s.is(SpiderMod.SPIDER_SUIT.get())) {
                sp.displayClientMessage(Component.literal("\u00a7cOnce kostumu giymelisin!"), true);
                return;
            }
            CompoundTag t = s.getOrCreateTag();
            boolean off = !t.getBoolean("MaskOff");
            t.putBoolean("MaskOff", off);
            sp.level().playSound(null, sp.getX(), sp.getY(), sp.getZ(),
                    SoundEvents.ARMOR_EQUIP_LEATHER, SoundSource.PLAYERS, 0.9F, off ? 1.4F : 1.0F);
            sp.displayClientMessage(Component.literal(off ? "\u00a77Maske: ACIK (yuzun gorunuyor)" : "\u00a76Maske: TAKILI"), true);
        });
        c.setPacketHandled(true);
    }
}
