package com.example.spidermod;

import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** Orumcek Adam kostumunun GeckoLib ek parcalari (amblem + ag kartusu). */
public class SpiderSuitGeoModel extends GeoModel<SpiderSuitItem> {
    @Override
    public ResourceLocation getModelResource(SpiderSuitItem animatable) {
        return new ResourceLocation(SpiderMod.MODID, "geo/spider_suit.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SpiderSuitItem animatable) {
        return new ResourceLocation(SpiderMod.MODID, "textures/armor/spider_suit_extras.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SpiderSuitItem animatable) {
        return new ResourceLocation(SpiderMod.MODID, "animations/spider_suit.animation.json");
    }
}
