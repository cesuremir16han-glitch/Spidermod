package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Iron Spider'in sirtindaki 4 mekanik bacagi (her biri 2 parca). */
public class IronLegsModel extends Model {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(SpiderMod.MODID, "iron_legs"), "main");
    public static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderMod.MODID, "textures/entity/iron_legs.png");

    private static final float[] ALPHA = {0.45F, 0.45F, 0.95F, 0.95F}; // yukari-disari aci
    private static final float[] BETA = {0.35F, 0.35F, 0.12F, 0.12F};  // arkaya yatma
    private static final float PHI = 0.55F;                              // alt parca bukulmesi

    private final ModelPart root;
    private final ModelPart[] upper = new ModelPart[4];
    private final ModelPart[] lower = new ModelPart[4];

    public IronLegsModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        for (int i = 0; i < 4; i++) {
            upper[i] = root.getChild("leg" + i);
            lower[i] = upper[i].getChild("low" + i);
        }
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        for (int i = 0; i < 4; i++) {
            float s = (i % 2 == 0) ? -1F : 1F;
            float y = i < 2 ? 2F : 6F;
            PartDefinition up = root.addOrReplaceChild("leg" + i,
                    CubeListBuilder.create().texOffs(0, 0).addBox(-0.75F, 0F, -0.75F, 1.5F, 7F, 1.5F),
                    PartPose.offset(s * 1.5F, y, 2.5F));
            up.addOrReplaceChild("low" + i,
                    CubeListBuilder.create().texOffs(0, 0).addBox(-0.5F, 0F, -0.5F, 1F, 8F, 1F),
                    PartPose.offset(0F, 7F, 0F));
        }
        return LayerDefinition.create(mesh, 16, 16);
    }

    public void animate(float age) {
        for (int i = 0; i < 4; i++) {
            float s = (i % 2 == 0) ? -1F : 1F;
            float wob = Mth.sin(age * 0.08F + i * 1.3F) * 0.06F;
            upper[i].xRot = BETA[i];
            upper[i].zRot = Mth.PI + s * (ALPHA[i] + wob);
            lower[i].zRot = -(Mth.PI + s * (ALPHA[i] + PHI + wob * 1.5F));
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay,
                               float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
