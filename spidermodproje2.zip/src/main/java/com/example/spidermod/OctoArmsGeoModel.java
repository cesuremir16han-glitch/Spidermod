package com.example.spidermod;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Oktopus kollari GeckoLib modeli. Asili kalirken alt iki kol yere kadar uzatilir (kodla olceklenir). */
public class OctoArmsGeoModel extends GeoModel<OctoArmsItem> {
    private static final Map<UUID, Float> PERCH_K = new HashMap<>();

    @Override
    public ResourceLocation getModelResource(OctoArmsItem animatable) {
        return new ResourceLocation(SpiderMod.MODID, "geo/octo_arms.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(OctoArmsItem animatable) {
        return new ResourceLocation(SpiderMod.MODID, "textures/armor/octo_arms.png");
    }

    @Override
    public ResourceLocation getAnimationResource(OctoArmsItem animatable) {
        return new ResourceLocation(SpiderMod.MODID, "animations/octo_arms.animation.json");
    }

    @Override
    public void setCustomAnimations(OctoArmsItem animatable, long instanceId, AnimationState<OctoArmsItem> state) {
        super.setCustomAnimations(animatable, instanceId, state);

        ItemStack stack = state.getData(DataTickets.ITEMSTACK);
        Entity ent = state.getData(DataTickets.ENTITY);
        if (ent == null) return;
        boolean perched = stack != null && stack.hasTag() && stack.getTag().getBoolean("Perched");

        float target = 1.0F;
        if (perched) { // omuzdan yere uzaklik kadar uzat
            Vec3 from = ent.position();
            BlockHitResult hit = ent.level().clip(new ClipContext(from, from.add(0, -48, 0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, ent));
            double h = hit.getType() == HitResult.Type.BLOCK ? from.y - hit.getLocation().y : 48.0D;
            target = (float) Mth.clamp((h * 16.0D + 15.0D) / 15.0D, 1.0D, 12.0D);
        }
        float cur = Mth.lerp(0.25F, PERCH_K.getOrDefault(ent.getUUID(), 1.0F), target);
        PERCH_K.put(ent.getUUID(), cur);

        if (perched || cur > 1.02F) { // alt iki kol (arm1, arm3) yere uzanir
            for (int i = 1; i <= 3; i += 2) {
                CoreGeoBone bone = getAnimationProcessor().getBone("arm" + i);
                if (bone != null) bone.setScaleY(cur);
            }
        }
    }
}
