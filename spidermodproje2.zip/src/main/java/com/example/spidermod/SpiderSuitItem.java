package com.example.spidermod;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;

import java.util.UUID;

/** Iron Spider nano kostumu (gogusluk). Gorunum SpiderSuitLayer ile cizilir; vanilla zirh katmani seffaf texture kullanir. */
public class SpiderSuitItem extends ArmorItem {
    private static final UUID SPEED_UUID = UUID.fromString("5f1c3a5e-7b0d-4f6a-9c1e-2a9d6b7e1c11");

    public SpiderSuitItem(ArmorMaterial material, Type type, Properties props) {
        super(material, type, props);
    }

    /** Kostum giyiliyken biraz daha hizli kos. */
    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        Multimap<Attribute, AttributeModifier> base = super.getAttributeModifiers(slot, stack);
        if (slot != EquipmentSlot.CHEST) return base;
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.putAll(base);
        b.put(Attributes.MOVEMENT_SPEED,
                new AttributeModifier(SPEED_UUID, "Spider speed", 0.15D, AttributeModifier.Operation.MULTIPLY_BASE));
        return b.build();
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return SpiderMod.MODID + ":textures/models/armor/blank.png";
    }
}
