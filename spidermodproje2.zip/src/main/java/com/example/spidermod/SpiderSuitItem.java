package com.example.spidermod;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;

import java.util.UUID;

/** Iron Spider nano kostumu. Gorunum SpiderSuitLayer ile cizilir; vanilla zirh katmani seffaf texture kullanir. */
public class SpiderSuitItem extends ArmorItem {
    private static final UUID SPEED_UUID = UUID.fromString("5c1a2f3e-7b4d-4a6e-9c2d-1f3b5a7c9e01");

    public SpiderSuitItem(ArmorMaterial material, Type type, Properties props) {
        super(material, type, props);
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        Multimap<Attribute, AttributeModifier> base = super.getDefaultAttributeModifiers(slot);
        if (slot != EquipmentSlot.CHEST) return base;
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.putAll(base);
        // biraz daha hizli kos (+%15)
        b.put(Attributes.MOVEMENT_SPEED,
                new AttributeModifier(SPEED_UUID, "Spider speed", 0.15D, AttributeModifier.Operation.MULTIPLY_BASE));
        return b.build();
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return SpiderMod.MODID + ":textures/models/armor/blank.png";
    }
}
