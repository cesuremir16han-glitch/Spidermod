package com.example.spidermod;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;
import java.util.function.Consumer;

/**
 * Orumcek Adam kostumu (gogusluk). Tum vucut gorunumu SpiderSuitLayer ile cizilir;
 * GeckoLib ile gogus/sirt uzerine animasyonlu ek parcalar (orumcek amblemi + ag kartusu) eklenir.
 * Durum NBT'den: WebOn (web shooter acik), WebMode.
 */
public class SpiderSuitItem extends ArmorItem implements GeoItem {
    private static final UUID SPEED_UUID = UUID.fromString("5f1c3a5e-7b0d-4f6a-9c1e-2a9d6b7e1c11");
    private static final UUID DAMAGE_UUID = UUID.fromString("a3d7c2b4-1e5f-4a89-b6c0-7d2e9f4a1b22");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public SpiderSuitItem(ArmorMaterial material, Type type, Properties props) {
        super(material, type, props);
    }

    /** Kostum giyiliyken biraz daha hizli kos, kilic gibi vur. */
    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
        Multimap<Attribute, AttributeModifier> base = super.getAttributeModifiers(slot, stack);
        if (slot != EquipmentSlot.CHEST) return base;
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.putAll(base);
        b.put(Attributes.MOVEMENT_SPEED,
                new AttributeModifier(SPEED_UUID, "Spider speed", 0.15D, AttributeModifier.Operation.MULTIPLY_BASE));
        b.put(Attributes.ATTACK_DAMAGE,
                new AttributeModifier(DAMAGE_UUID, "Spider strength", 6.0D, AttributeModifier.Operation.ADDITION));
        return b.build();
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private SpiderSuitRenderer renderer;

            @Override
            public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                          EquipmentSlot slot, HumanoidModel<?> original) {
                if (this.renderer == null) this.renderer = new SpiderSuitRenderer();
                this.renderer.prepForRender(entity, stack, slot, original);
                return this.renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 6, state -> {
            ItemStack stack = state.getData(DataTickets.ITEMSTACK);
            CompoundTag t = stack != null && stack.hasTag() ? stack.getTag() : null;
            boolean webOn = t != null && t.getBoolean("WebOn");
            return state.setAndContinue(RawAnimation.begin().thenLoop(webOn ? "web_on" : "idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return SpiderMod.MODID + ":textures/models/armor/blank.png";
    }
}
