package com.example.spidermod;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;

/**
 * Doktor Oktopus kollari (pantolon slotu) - GeckoLib ile animasyonlu.
 * Durum esyanin NBT'sinden okunur: Open, Holding, Perched, Strike.
 * Animasyonlar: assets/spidermod/animations/octo_arms.animation.json (Blockbench ile duzenlenebilir).
 */
public class OctoArmsItem extends ArmorItem implements GeoItem {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public OctoArmsItem(ArmorMaterial material, Type type, Properties props) {
        super(material, type, props);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private OctoArmsRenderer renderer;

            @Override
            public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack,
                                                          EquipmentSlot slot, HumanoidModel<?> original) {
                if (this.renderer == null) this.renderer = new OctoArmsRenderer();
                this.renderer.prepForRender(entity, stack, slot, original);
                return this.renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 6, state -> {
            ItemStack stack = state.getData(DataTickets.ITEMSTACK);
            CompoundTag t = stack != null && stack.hasTag() ? stack.getTag() : null;
            boolean open = t != null && t.getBoolean("Open");
            String anim;
            if (!open) anim = "closed";
            else if (t.getBoolean("Strike")) anim = "attack";
            else if (t.getBoolean("Holding")) anim = "hold";
            else if (t.getBoolean("Climbing")) anim = "climb";
            else if (t.getBoolean("Perched")) anim = "perch";
            else anim = "open";
            RawAnimation raw = anim.equals("attack")
                    ? RawAnimation.begin().thenPlay(anim)
                    : RawAnimation.begin().thenLoop(anim);
            return state.setAndContinue(raw);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return SpiderMod.MODID + ":textures/models/armor/blank.png";
    }
}
