package com.example.spidermod;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;

/** Doktor Oktopus kollari (pantolon slotu). Gorunum OctoArmsLayer ile cizilir; vanilla zirh katmani seffaf. */
public class OctoArmsItem extends ArmorItem {
    public OctoArmsItem(ArmorMaterial material, Type type, Properties props) {
        super(material, type, props);
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return SpiderMod.MODID + ":textures/models/armor/blank.png";
    }
}
