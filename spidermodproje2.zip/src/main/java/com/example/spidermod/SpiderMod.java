package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraftforge.client.event.InputEvent;
import net.minecraft.world.level.ClipContext;
import net.minecraft.tags.BlockTags;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import java.util.ArrayList;
import java.util.List;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.glfw.GLFW;

/**
 * Spider Mod (Forge 1.20.1) - Orumcek Adam kostumu
 *
 *  - Gogusluk = tum vucut Orumcek Adam kostumu (giyince hemen gorunur)
 *  - G: MASKE ac/kapat (maske acikken Peter Parker yuzu gorunur)
 *  - Kostumle: bos el = balta/kazma/kurek gibi kirar (elmas arac hizi), kilic gibi vurus, biraz daha yuksege zipla, biraz daha hizli kos, dusme hasari YOK
 *  - PANTOLON = Doktor Oktopus kollari: H ac/kapat; acikken 2. ziplamada havada asili kalir (alt 2 kol yere tutunur), SPACE basili = yerden en fazla 6 blok yuksel,
 *    SHIFT = asagi in, sol tik = kollarla vur, J = yaratik tut/firlat (kostumle birlikte calisir)
 *  - Y: Web Shooter ac/kapat | SHIFT+Y: ag modu sec (Y+SHIFT basiliyken 1=sallanma 2=seken 3=yapistirici 4=kopru)
 *  - Web Shooter ACIKKEN bos elle SAG TIKI BASILI TUT:
 *        normal    -> ag atilir, sallanirsin (asagi inerken hizlanirsin, SPACE: ipi birak ve firla)
 *        SHIFT ile -> WEB ZIP: baktigin yere hizla atilirsin (duvara/tavana bakarsan yapisirsin)
 *  - Duvar tirmanma: duvarin onunde SHIFT + SPACE -> mod acilir; baktigin yone ucar gibi gidersin
 *        yukarida tavan varsa otomatik tavana gecersin
 *  - Efektler: puruzsuz ag cizgisi, sallanirken FOV/egilme/ayak hareketi, tirmanirken parcacik/ses
 */
@Mod(SpiderMod.MODID)
public class SpiderMod {
    public static final String MODID = "spidermod";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final RegistryObject<Block> WEB_BRIDGE = BLOCKS.register("web_bridge",
            () -> new WebBridgeBlock(BlockBehaviour.Properties.of()
                    .strength(0.1F).sound(SoundType.WOOL).noOcclusion().noLootTable()));

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> SPIDER_SUIT = ITEMS.register("spider_suit",
            () -> new SpiderSuitItem(SuitMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1).fireResistant()));

    public static final RegistryObject<Item> OCTO_ARMS = ITEMS.register("octo_arms",
            () -> new OctoArmsItem(SuitMaterial.INSTANCE, ArmorItem.Type.LEGGINGS,
                    new Item.Properties().stacksTo(1).fireResistant()));

    public SpiderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        BLOCKS.register(bus);
        bus.addListener(this::addCreative);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(Net::register);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) {
            e.accept(SPIDER_SUIT);
            e.accept(OCTO_ARMS);
        }
    }

    /** G ile maske acildi mi (kostumun basi gizli, kendi yuzun gorunur). */
    public static boolean maskOff(Player p) {
        net.minecraft.world.item.ItemStack st = p.getItemBySlot(EquipmentSlot.CHEST);
        return st.is(SPIDER_SUIT.get()) && st.hasTag() && st.getTag().getBoolean("MaskOff");
    }

    /** Doktor Oktopus kollari pantolon slotunda mi. */
    public static boolean wearingArms(Player p) {
        return p.getItemBySlot(EquipmentSlot.LEGS).is(OCTO_ARMS.get());
    }

    /** Kollar H ile acildi mi. */
    public static boolean armsOpen(Player p) {
        net.minecraft.world.item.ItemStack st = p.getItemBySlot(EquipmentSlot.LEGS);
        return st.is(OCTO_ARMS.get()) && st.hasTag() && st.getTag().getBoolean("Open");
    }

    /** Kollar bir yaratigi tutuyor mu. */
    public static boolean armsHolding(Player p) {
        net.minecraft.world.item.ItemStack st = p.getItemBySlot(EquipmentSlot.LEGS);
        return st.is(OCTO_ARMS.get()) && st.hasTag() && st.getTag().getBoolean("Holding");
    }

    /** Kollar havada asili modda mi (alt iki kol yere tutunmus). */
    public static boolean armsPerched(Player p) {
        net.minecraft.world.item.ItemStack st = p.getItemBySlot(EquipmentSlot.LEGS);
        return st.is(OCTO_ARMS.get()) && st.hasTag() && st.getTag().getBoolean("Perched");
    }

    public static boolean wearingSuit(Player p) {
        return p.getItemBySlot(EquipmentSlot.CHEST).is(SPIDER_SUIT.get());
    }

    // ---------------- SUNUCU + ISTEMCI ----------------
    @Mod.EventBusSubscriber(modid = MODID)
    public static class CommonEvents {
        /** Kostumle bos el = balta / kazma / kurek / capa gibi kirar. */
        private static boolean handTool(Player p, BlockState st) {
            return wearingSuit(p) && p.getMainHandItem().isEmpty()
                    && (st.is(BlockTags.MINEABLE_WITH_PICKAXE) || st.is(BlockTags.MINEABLE_WITH_AXE)
                    || st.is(BlockTags.MINEABLE_WITH_SHOVEL) || st.is(BlockTags.MINEABLE_WITH_HOE));
        }

        @SubscribeEvent
        public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
            if (handTool(e.getEntity(), e.getState())) {
                e.setNewSpeed(Math.max(e.getNewSpeed(), 8.0F)); // elmas arac hizi
            }
        }

        @SubscribeEvent
        public static void onHarvestCheck(PlayerEvent.HarvestCheck e) {
            if (handTool(e.getEntity(), e.getTargetBlock())) {
                e.setCanHarvest(true); // tas, maden, odun... dogru esyayi birakir
            }
        }

        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent e) {
            if (e.phase == TickEvent.Phase.END) {
                WebShotPacket.tickTempWebs();
                ArmsPacket.tickHeld(e.getServer());
                ArmsPacket.tickStrikes(e.getServer());
            }
        }

        @SubscribeEvent
        public static void onJump(LivingEvent.LivingJumpEvent e) {
            if (e.getEntity() instanceof Player p && wearingSuit(p)) {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x, v.y + 0.08D, v.z); // biraz daha yuksege zipla
            }
        }

        @SubscribeEvent
        public static void onFall(LivingFallEvent e) {
            if (e.getEntity() instanceof Player p && wearingSuit(p)) {
                e.setDamageMultiplier(0.0F); // hic dusme hasari alma
                e.setDistance(0.0F);
            } else if (e.getEntity() instanceof Player p2 && armsOpen(p2)) {
                e.setDamageMultiplier(0.3F); // kollar inisi yumusatir
            }
        }
    }

    // ---------------- ISTEMCI (MOD BUS) ----------------
    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            e.register(ClientEvents.WEB_KEY);
            e.register(ClientEvents.SUIT_KEY);
            e.register(ClientEvents.ARMS_KEY);
            e.register(ClientEvents.GRAB_KEY);
        }

        @SubscribeEvent
        public static void layerDefs(EntityRenderersEvent.RegisterLayerDefinitions e) {
            e.registerLayerDefinition(SpiderSuitLayer.WIDE, () -> SpiderSuitLayer.createLayer(false));
            e.registerLayerDefinition(SpiderSuitLayer.SLIM, () -> SpiderSuitLayer.createLayer(true));
        }

        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers e) {
            for (String skin : e.getSkins()) {
                PlayerRenderer r = e.getSkin(skin);
                if (r != null) {
                    r.addLayer(new SpiderSuitLayer(r, e.getEntityModels()));
                }
            }
        }
    }

    // ---------------- ISTEMCI (FORGE BUS) ----------------
    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT)
    public static class ClientEvents {
        public static final KeyMapping WEB_KEY =
                new KeyMapping("key.spidermod.web_toggle", GLFW.GLFW_KEY_Y, "key.categories.spidermod");
        public static final KeyMapping SUIT_KEY =
                new KeyMapping("key.spidermod.suit_toggle", GLFW.GLFW_KEY_G, "key.categories.spidermod");

        public static final KeyMapping ARMS_KEY =
                new KeyMapping("key.spidermod.arms_toggle", GLFW.GLFW_KEY_H, "key.categories.spidermod");
        public static final KeyMapping GRAB_KEY =
                new KeyMapping("key.spidermod.arms_grab", GLFW.GLFW_KEY_J, "key.categories.spidermod");

        private static final Vec3 UP = new Vec3(0, 1, 0);

        // ag durumu
        private static boolean webActive = false;
        private static int webMode = 0; // 0 = sallanma, 1 = seken, 2 = yapistirici, 3 = kopru agi
        private static final String[] MODE_NAMES = {"SALLANMA AGI", "SEKEN AG", "YAPISTIRICI AG", "KOPRU AGI"};

        /** Web shooter acik/kapali ve modu esyaya yazilir (GeckoLib kostum animasyonlari icin, herkese senkron). */
        private static void syncSuitState() {
            Net.CHANNEL.sendToServer(new SuitStatePacket(webActive ? 1 : 0, webMode));
        }

        /** Ekranda mod listesi: secili olan yesil kosegeli. */
        private static String modeMenu() {
            StringBuilder sb = new StringBuilder("§bAg modu: ");
            for (int i = 0; i < MODE_NAMES.length; i++) {
                sb.append(i == webMode ? "§a[" + (i + 1) + "] " : "§7" + (i + 1) + " ")
                        .append(MODE_NAMES[i]).append("  ");
            }
            return sb.toString();
        }

        /** Y + SHIFT basiliyken 1/2/3/4 ile dogrudan mod sec (hotbar degismesin diye tick basinda yakalanir). */
        @SubscribeEvent
        public static void onKeyMode(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.START) return;
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || mc.screen != null) return;
            if (!WEB_KEY.isDown() || !mc.options.keyShift.isDown() || !wearingSuit(p)) return;
            for (int i = 0; i < MODE_NAMES.length; i++) {
                while (mc.options.keyHotbarSlots[i].consumeClick()) {
                    webMode = i;
                    webActive = true;
                    p.displayClientMessage(Component.literal(modeMenu()), true); syncSuitState();
                }
            }
        }

        /** Sol tik: kollar aciksa kollarla vur (yaratiga bakiyorsan normal vurusun yerine kollar vurur). */
        @SubscribeEvent
        public static void onAttackKey(InputEvent.InteractionKeyMappingTriggered e) {
            if (!e.isAttack()) return;
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || !armsOpen(p)) return;
            Net.CHANNEL.sendToServer(new ArmsPacket(1));
            if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.ENTITY) {
                e.setSwingHand(true);
                e.setCanceled(true);
            }
        }

        private static class Bolt {
            final List<Vec3> pts;
            final int mode;
            int age = 0;

            Bolt(List<Vec3> pts, int mode) {
                this.pts = pts;
                this.mode = mode;
            }
        }

        private static final List<Bolt> BOLTS = new ArrayList<>();

        /** Sunucudan gelen ag cizgisini goster (WebBoltPacket). */
        public static void addBolt(List<Vec3> pts, int mode) {
            BOLTS.add(new Bolt(pts, mode));
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null && !pts.isEmpty()) {
                Vec3 last = pts.get(pts.size() - 1);
                for (int i = 0; i < 8; i++) {
                    mc.level.addParticle(ParticleTypes.CLOUD, last.x, last.y, last.z,
                            (mc.level.random.nextDouble() - 0.5D) * 0.1D,
                            (mc.level.random.nextDouble() - 0.5D) * 0.1D,
                            (mc.level.random.nextDouble() - 0.5D) * 0.1D);
                }
            }
        }
        private static Vec3 anchor = null;
        private static Direction anchorFace = Direction.UP;
        private static double ropeLen = 0;
        private static boolean zip = false;
        private static boolean fired = false;
        private static int webAge = 0;
        private static int zipTicks = 0;

        // tirmanma durumu: 0 = yok, 1 = duvar, 2 = tavan
        private static int climbType = 0;
        private static Vec3 climbPush = Vec3.ZERO;
        private static int lostContact = 0;
        private static boolean prevJump = false;
        private static Vec3 climbVel = Vec3.ZERO;
        private static boolean attached = false;
        private static int approachTicks = 0;
        private static boolean climbMoving = false;
        private static Vec3 poseDir = new Vec3(0, 1, 0); // vucudun duvarda/tavanda baktigi (basin yonu)
        private static boolean poseApplied = false;

        // gorsel efektler
        private static float fovTarget = 0F;
        private static float fovBonus = 0F;
        private static float rollTarget = 0F;
        private static float rollSmooth = 0F;

        /** 0 = yok, 1 = sallanma, 2 = zip, 3 = duvar, 4 = tavan (katman pozlari icin). */
        public static int poseMode() {
            if (anchor != null) return zip ? 2 : 1;
            if (climbType == 1) return 3;
            if (climbType == 2) return 4;
            return 0;
        }

        public static boolean climbMoving() {
            return climbMoving;
        }

        /** Poz oynarken kendi derimizin kol/bacaklarini gizle + duvar/tavan pozunda govdeyi yatir. */
        @SubscribeEvent
        public static void onPlayerPre(RenderPlayerEvent.Pre e) {
            PlayerModel<AbstractClientPlayer> pm = e.getRenderer().getModel();
            boolean local = e.getEntity() == Minecraft.getInstance().player;
            boolean hide = local && poseMode() != 0 && wearingSuit(e.getEntity())
                    && SpiderSuitLayer.fullyWorn(e.getEntity());
            boolean climbPose = hide && (climbType == 1 || climbType == 2);
            pm.leftLeg.skipDraw = hide;
            pm.rightLeg.skipDraw = hide;
            pm.leftArm.skipDraw = hide;
            pm.rightArm.skipDraw = hide;
            pm.leftPants.skipDraw = hide;
            pm.rightPants.skipDraw = hide;
            pm.leftSleeve.skipDraw = hide;
            pm.rightSleeve.skipDraw = hide;
            pm.head.skipDraw = climbPose; // kostum basi (maske ya da yuz) ustte cizilir
            pm.hat.skipDraw = wearingSuit(e.getEntity()); // deri sapkasi/sac katmani kostumun disina tasmasin

            poseApplied = false;
            if (climbPose) {
                // Gmod tarzi: gogus duvara/tavana yapisik, vucut hareket yonune dogru yatik (ucar gibi)
                Player pl = e.getEntity();
                Vec3 nIn = climbType == 2 ? UP : climbPush.normalize();
                Vec3 d = poseDir;
                float a = Mth.rotLerp(e.getPartialTick(), pl.yBodyRotO, pl.yBodyRot) * Mth.DEG_TO_RAD;
                Vec3 f = new Vec3(-Mth.sin(a), 0, Mth.cos(a));
                Vec3 uThird = UP.cross(f);
                Vec3 tThird = d.cross(nIn);
                Matrix3f u = new Matrix3f(
                        (float) uThird.x, (float) uThird.y, (float) uThird.z,
                        (float) UP.x, (float) UP.y, (float) UP.z,
                        (float) f.x, (float) f.y, (float) f.z);
                Matrix3f t = new Matrix3f(
                        (float) tThird.x, (float) tThird.y, (float) tThird.z,
                        (float) d.x, (float) d.y, (float) d.z,
                        (float) nIn.x, (float) nIn.y, (float) nIn.z);
                Matrix3f r = t.mul(u.transpose());
                Quaternionf q = new Quaternionf().setFromUnnormalized(r);

                PoseStack ps = e.getPoseStack();
                ps.pushPose();
                double lift = climbType == 2 ? 0.8D : 0.0D; // tavanda govde tavana dayansin
                ps.translate(nIn.x * 0.12D, nIn.y * 0.12D + lift, nIn.z * 0.12D);
                ps.translate(0, 0.9D, 0);
                ps.mulPose(q);
                ps.translate(0, -0.9D, 0);
                poseApplied = true;
            }
        }

        @SubscribeEvent
        public static void onPlayerPost(RenderPlayerEvent.Post e) {
            if (poseApplied) {
                e.getPoseStack().popPose();
                poseApplied = false;
            }
        }

        private static void updatePoseDir(Vec3 target) {
            Vec3 np = poseDir.lerp(target.normalize(), 0.25D);
            if (np.lengthSqr() > 1.0E-4D) poseDir = np.normalize();
        }

        private static Vec3 yawDir(LocalPlayer p) {
            double y = Math.toRadians(p.getYRot());
            return new Vec3(-Math.sin(y), 0, Math.cos(y));
        }

        // ============ ANA TICK ============
        @SubscribeEvent
        public static void onTick(TickEvent.PlayerTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            if (!(e.player instanceof LocalPlayer p)) return;
            Minecraft mc = Minecraft.getInstance();

            BOLTS.removeIf(b -> ++b.age > 8);
            boolean suit = wearingSuit(p);
            boolean jumpEdge = p.input.jumping && !prevJump; // SPACE'e yeni basildi
            prevJump = p.input.jumping;

            while (SUIT_KEY.consumeClick()) { // maske ac/kapat
if (!wearingSuit(p)) {
                    p.displayClientMessage(Component.literal("§cOnce kostumu giymelisin!"), true);
                } else {
                    Net.CHANNEL.sendToServer(new ToggleSuitPacket());
                }
            }

            while (ARMS_KEY.consumeClick()) { // Oktopus kollarini ac/kapat
                if (!wearingArms(p)) {
                    p.displayClientMessage(Component.literal("§cOnce Doktor Oktopus kollarini (pantolon) giymelisin!"), true);
                } else {
                    Net.CHANNEL.sendToServer(new ArmsPacket(0));
                }
            }
            while (GRAB_KEY.consumeClick()) { // yaratik tut / firlat
                if (!armsOpen(p)) {
                    p.displayClientMessage(Component.literal("§cOnce kollari ac (H)!"), true);
                } else {
                    Net.CHANNEL.sendToServer(new ArmsPacket(2));
                }
            }

            while (WEB_KEY.consumeClick()) {
                if (!suit) {
                    p.displayClientMessage(Component.literal("§cOrumcek kostumunu giymelisin!"), true);
                } else if (p.isShiftKeyDown()) { // SHIFT + Y: ag modu sec
                    webMode = (webMode + 1) % MODE_NAMES.length;
                    webActive = true;
                    p.displayClientMessage(Component.literal(modeMenu()), true); syncSuitState();
                } else {
                    webActive = !webActive;
                    p.displayClientMessage(Component.literal(webActive
                            ? "§aWeb Shooter: ACIK §7(" + MODE_NAMES[webMode] + ")"
                            : "§7Web Shooter: KAPALI"), true); syncSuitState();
                }
            }
            if (!suit) webActive = false;

            boolean holding = webActive && mc.screen == null
                    && mc.options.keyUse.isDown()
                    && p.getMainHandItem().isEmpty();

            if (!holding || p.isDeadOrDying()) {
                anchor = null;
                fired = false;
            } else if (!fired) {
                fired = true;
                if (webMode != 0) { // seken / yapistirici ag: tek atis, sunucuda hesaplanir
                    Net.CHANNEL.sendToServer(new WebShotPacket(webMode));
                    p.swing(InteractionHand.MAIN_HAND);
                }
                HitResult hit = webMode == 0 ? p.pick(60.0D, 1.0F, false) : null;
                if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
                    anchor = bhr.getLocation();
                    anchorFace = bhr.getDirection();
                    zip = p.isShiftKeyDown();
                    ropeLen = Math.max(3.0D, anchor.distanceTo(p.getEyePosition()) * 0.85D);
                    webAge = 0;
                    zipTicks = 0;
                    climbType = 0;
                    p.swing(InteractionHand.MAIN_HAND);
                    p.level().playLocalSound(p.getX(), p.getY(), p.getZ(),
                            SoundEvents.FISHING_BOBBER_THROW, SoundSource.PLAYERS, 1.0F, 1.3F, false);
                    for (int i = 0; i < 8; i++) { // ag carpma efekti
                        p.level().addParticle(ParticleTypes.CLOUD, anchor.x, anchor.y, anchor.z,
                                (p.getRandom().nextDouble() - 0.5D) * 0.1D,
                                (p.getRandom().nextDouble() - 0.5D) * 0.1D,
                                (p.getRandom().nextDouble() - 0.5D) * 0.1D);
                    }
                }
            }

            fovTarget = 0F;
            rollTarget = 0F;

            if (anchor != null) {
                setPerched(false);
                setArmsClimb(false);
                tickWeb(p, jumpEdge);
            } else {
                tickClimb(p, suit, jumpEdge);
                if (climbType == 0) tickArmsMove(p, jumpEdge);
                else setPerched(false);
            }
        }

        // ============ AG: SALLANMA + ZIP ============
        private static void tickWeb(LocalPlayer p, boolean jumpEdge) {
            climbType = 0;
            webAge++;

            Vec3 eye = p.getEyePosition();
            Vec3 to = anchor.subtract(eye);
            double d = to.length();
            if (d < 0.3D) {
                anchor = null;
                return;
            }
            Vec3 dir = to.scale(1.0D / d);
            Vec3 v = p.getDeltaMovement();

            if (zip) {
                // WEB ZIP: baktigin noktaya dogru hizli atilim (SPACE'e bakmaz)
                zipTicks++;
                if (zipArrived(p, d)) {
                    arrive(p);
                    return;
                }
                v = dir.scale(Math.min(0.95D, 0.35D + d * 0.06D));
            } else {
                // SALLANMA
                if (jumpEdge) { // SPACE'e yeni basinca birak + firla (hiz yuksekse daha cok firlar)
                    double boost = 1.25D + Math.min(0.35D, v.length() * 0.3D);
                    p.setDeltaMovement(v.scale(boost).add(0, 0.2D, 0));
                    anchor = null;
                    return;
                }
                if (d > ropeLen) {
                    double radial = v.dot(dir);
                    if (radial < 0) v = v.subtract(dir.scale(radial));
                    v = v.add(dir.scale(Math.min(0.5D, (d - ropeLen) * 0.15D)));
                }
                if (v.y < -0.05D && v.length() < 1.9D) { // asagi inerken hizlan
                    v = v.scale(1.035D);
                }
                if (p.input.forwardImpulse > 0) {
                    v = v.add(p.getLookAngle().scale(0.03D));
                }
                if (v.length() > 2.2D) v = v.normalize().scale(2.2D);
                // sallanirken yana egilme
                Vec3 right = p.getLookAngle().cross(UP);
                if (right.lengthSqr() > 1.0E-4D) {
                    double lateral = v.dot(right.normalize());
                    rollTarget = (float) Mth.clamp(-lateral * 30.0D, -14.0D, 14.0D);
                }
            }

            p.setDeltaMovement(v);
            p.fallDistance = 0;

            double speed = v.length();
            fovTarget = (float) Mth.clamp((speed - 0.25D) * 35.0D, 0.0D, 18.0D);
            windFx(p, v, speed);
        }

        // ============ OKTOPUS KOLLARI: HAVADA ASILI KALMA ============
        private static int airJumps = 0;
        private static boolean perched = false;
        private static int perchRise = 0;

        private static boolean armsClimb = false; // Oktopus kollariyla duvara tirmaniyor
        private static int armsClimbCd = 0;

        private static void setArmsClimb(boolean on) {
            if (armsClimb != on) {
                armsClimb = on;
                Net.CHANNEL.sendToServer(new ArmsPacket(on ? 5 : 6));
            }
        }

        private static void setPerched(boolean on) {
            if (perched != on) {
                perched = on;
                Net.CHANNEL.sendToServer(new ArmsPacket(on ? 3 : 4));
            }
        }

        /** Ayaklarin altindaki zemine uzaklik (blok). */
        private static double groundDist(LocalPlayer p) {
            Vec3 from = p.position();
            BlockHitResult hit = p.level().clip(new ClipContext(from, from.add(0, -64, 0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            return hit.getType() == HitResult.Type.BLOCK ? from.y - hit.getLocation().y : 64.0D;
        }

        /**
         * Kollar aciksa: havada 2. ziplama = olunan yerde asili kal (alt iki kol yere tutunur),
         * SPACE basili = yukselir (yerden en fazla 6 blok), SHIFT = asagi iner, yere degince biter.
         */
        private static void tickArmsMove(LocalPlayer p, boolean jumpEdge) {
            if (armsClimb) { // tirmanma bitti
                setArmsClimb(false);
                armsClimbCd = 10;
            }
            if (armsClimbCd > 0) armsClimbCd--;
            // duvara dogru giderken ust kollar duvara tutunur, onlarla duvarda yuruyoruz
            if (armsClimbCd == 0 && armsOpen(p) && !p.isInWater() && !p.isDeadOrDying() && !p.isPassenger()
                    && !p.getAbilities().flying && p.input.forwardImpulse > 0 && p.horizontalCollision) {
                Direction wd = wallDir(p);
                if (wd != null) {
                    climbPush = new Vec3(wd.getStepX() * 0.1D, 0, wd.getStepZ() * 0.1D);
                    climbType = 1;
                    lostContact = 0;
                    attached = true;
                    approachTicks = 0;
                    climbVel = Vec3.ZERO;
                    poseDir = UP;
                    setPerched(false);
                    setArmsClimb(true);
                    p.setDeltaMovement(climbPush.x, 0, climbPush.z);
                    p.fallDistance = 0;
                    return;
                }
            }
            if (!armsOpen(p) || p.isInWater() || p.isDeadOrDying() || p.getAbilities().flying
                    || p.isPassenger() || p.onGround()) {
                airJumps = 0;
                perchRise = 0;
                setPerched(false);
                return;
            }
            if (!perched) {
                if (jumpEdge && airJumps < 1) { // cift ziplama: azicik yuksel ve asili kal
                    airJumps++;
                    perchRise = 4;
                    setPerched(true);
                } else {
                    return;
                }
            }
            Vec3 v = p.getDeltaMovement();
            double vy;
            if (perchRise > 0) {
                vy = 0.3D;
                perchRise--;
            } else if (p.isShiftKeyDown()) {
                vy = -0.3D;
            } else if (p.input.jumping) {
                vy = groundDist(p) < 6.0D ? 0.25D : 0.0D;
            } else {
                vy = 0.0D; // oldugun yerde kal
            }
            p.setDeltaMovement(v.x * 0.85D, vy, v.z * 0.85D);
            p.fallDistance = 0;
        }

        private static boolean zipArrived(LocalPlayer p, double d) {
            if (zipTicks > 40) return true;
            if (anchorFace == Direction.UP) return d < 2.2D;
            if (anchorFace == Direction.DOWN) return d < 0.6D || (d < 3.0D && ceilingAbove(p));
            return d < 0.8D || (d < 3.0D && wallDir(p) != null);
        }

        /** Zip bitince: duvara bakildiysa duvara, tavana bakildiysa tavana yapis. */
        private static void arrive(LocalPlayer p) {
            Direction f = anchorFace;
            anchor = null;
            p.setDeltaMovement(Vec3.ZERO);
            if (f.getAxis().isHorizontal()) {
                climbPush = new Vec3(-f.getStepX() * 0.1D, 0, -f.getStepZ() * 0.1D);
                climbType = 1;
                lostContact = 0;
                attached = false;
                approachTicks = 0;
                climbVel = Vec3.ZERO;
                p.setDeltaMovement(climbPush.scale(3.0D)); // duvara dogru yaslan, dusme
                poseDir = UP;
                p.displayClientMessage(Component.literal("§aDuvara yapistin"), true);
            } else if (f == Direction.DOWN) {
                climbType = 2;
                lostContact = 0;
                attached = false;
                approachTicks = 0;
                climbVel = Vec3.ZERO;
                p.setDeltaMovement(0, 0.3D, 0); // tavana dogru yaslan
                poseDir = yawDir(p);
                p.displayClientMessage(Component.literal("§aTavana yapistin"), true);
            }
        }

        // ============ DUVAR / TAVAN TIRMANMA ============
        private static void tickClimb(LocalPlayer p, boolean suit, boolean jumpEdge) {
            if (armsClimb && !armsOpen(p)) setArmsClimb(false);
            if ((!suit && !armsClimb) || p.isInWater() || p.isDeadOrDying()) climbType = 0;
            if (climbType == 0) climbMoving = false;

            if (climbType != 0) {
                if (jumpEdge) {
                    boolean drop = p.isShiftKeyDown() || climbType == 2;
                    armsClimbCd = 15;
                    climbType = 0;
                    if (!drop) { // duvardan siçra
                        Vec3 look = p.getLookAngle();
                        p.setDeltaMovement(look.x * 0.6D, 0.6D, look.z * 0.6D);
                    }
                    return;
                }

                boolean moving;
                if (climbType == 1) {
                    // ---- DUVAR ----
                    if (wallDir(p) != null) {
                        attached = true;
                        lostContact = 0;
                    } else if (attached) {
                        lostContact++;
                        if (lostContact > 8) { // duvarin tepesi
                            climbType = 0;
                            return;
                        }
                    } else {
                        approachTicks++;
                        if (approachTicks > 15) { // duvara ulasilamadi
                            climbType = 0;
                            return;
                        }
                    }
                    Vec3 push = attached ? climbPush : climbPush.scale(3.0D);

                    // ucar gibi: duvar yuzeyinde baktigin yone dumduz git
                    Vec3 nIn = climbPush.normalize();
                    Vec3 lk = p.getLookAngle();
                    Vec3 lp = lk.subtract(nIn.scale(lk.dot(nIn)));
                    Vec3 dirV = lp.length() < 0.25D ? UP : lp.normalize();
                    Vec3 leftV = new Vec3(nIn.z, 0, -nIn.x);
                    Vec3 tv = dirV.scale(Math.signum(p.input.forwardImpulse))
                            .add(leftV.scale(Math.signum(p.input.leftImpulse)));
                    double tl = tv.length();
                    tv = tl > 1.0E-4D ? tv.scale((armsClimb ? 0.36D : 0.22D) / tl) : Vec3.ZERO; // kollarla yurumek daha hizli
                    if (tl > 1.0E-4D) updatePoseDir(tv);

                    if (tv.y > 0.05D && ceilingAbove(p)) { // yukarida tavan var -> tavana gec
                        climbType = 2;
                        lostContact = 0;
                        attached = true;
                        approachTicks = 0;
                        climbVel = Vec3.ZERO;
                        p.setDeltaMovement(0, 0.1D, 0);
                        poseDir = yawDir(p);
                        p.displayClientMessage(Component.literal("§aTavana gectin"), true);
                        return;
                    }
                    if (tv.y < -0.05D && p.onGround()) {
                        climbType = 0;
                        return;
                    }
                    climbVel = climbVel.lerp(tv, 0.35D); // puruzsuz hizlanma
                    p.setDeltaMovement(climbVel.x + push.x, climbVel.y, climbVel.z + push.z);
                    moving = tl > 1.0E-4D;
                } else {
                    // ---- TAVAN ----
                    if (ceilingAbove(p)) {
                        attached = true;
                        lostContact = 0;
                    } else if (attached) {
                        lostContact++;
                        if (lostContact > 8) { // tavanin kenari
                            climbType = 0;
                            return;
                        }
                    } else {
                        approachTicks++;
                        if (approachTicks > 15) {
                            climbType = 0;
                            return;
                        }
                    }
                    double upPush = attached ? 0.1D : 0.3D;
                    double fx = Math.signum(p.input.leftImpulse);
                    double fz = Math.signum(p.input.forwardImpulse);
                    double yaw = Math.toRadians(p.getYRot());
                    double mx = fx * Math.cos(yaw) - fz * Math.sin(yaw);
                    double mz = fz * Math.cos(yaw) + fx * Math.sin(yaw);
                    double len = Math.sqrt(mx * mx + mz * mz);
                    Vec3 tv = len > 1.0E-4D ? new Vec3(mx / len * 0.18D, 0, mz / len * 0.18D) : Vec3.ZERO;
                    if (len > 1.0E-4D) updatePoseDir(tv);
                    climbVel = climbVel.lerp(tv, 0.35D);
                    p.setDeltaMovement(climbVel.x, upPush, climbVel.z);
                    moving = len > 1.0E-4D;
                }
                climbMoving = moving;
                p.fallDistance = 0;
                climbFx(p, moving);
                return;
            }

            // ---- MODU AC: SHIFT + SPACE (duvar veya tavan yakininda) ----
            if (suit && jumpEdge && p.isShiftKeyDown() && !p.isInWater()) {
                Direction wd = wallDir(p);
                if (wd != null) {
                    climbPush = new Vec3(wd.getStepX() * 0.1D, 0, wd.getStepZ() * 0.1D);
                    climbType = 1;
                    lostContact = 0;
                    attached = true;
                    approachTicks = 0;
                    climbVel = Vec3.ZERO;
                    p.setDeltaMovement(climbPush.x, 0, climbPush.z); // gecis aninda asagi dusme
                    poseDir = UP;
                    p.fallDistance = 0;
                    p.displayClientMessage(Component.literal("§aDuvara tirmanma: ACIK"), true);
                } else if (ceilingAbove(p)) {
                    climbType = 2;
                    lostContact = 0;
                    attached = true;
                    approachTicks = 0;
                    climbVel = Vec3.ZERO;
                    p.setDeltaMovement(0, 0.1D, 0);
                    p.fallDistance = 0;
                    poseDir = yawDir(p);
                    p.displayClientMessage(Component.literal("§aTavana tirmanma: ACIK"), true);
                }
            }
        }

        /** Yakinda duvar varsa o yonu verir (once bakilan yon). */
        private static Direction wallDir(LocalPlayer p) {
            AABB bb = p.getBoundingBox().inflate(0, -0.1D, 0);
            Direction first = p.getDirection();
            if (!p.level().noCollision(p, bb.move(first.getStepX() * 0.2D, 0, first.getStepZ() * 0.2D))) return first;
            for (Direction d : Direction.Plane.HORIZONTAL) {
                if (d == first) continue;
                if (!p.level().noCollision(p, bb.move(d.getStepX() * 0.2D, 0, d.getStepZ() * 0.2D))) return d;
            }
            return null;
        }

        private static boolean ceilingAbove(LocalPlayer p) {
            AABB bb = p.getBoundingBox().inflate(-0.1D, 0, -0.1D).move(0, 0.15D, 0);
            return !p.level().noCollision(p, bb);
        }

        // ============ EFEKTLER ============
        private static void windFx(LocalPlayer p, Vec3 v, double speed) {
            if (speed < 0.5D) return;
            for (int i = 0; i < 2; i++) {
                p.level().addParticle(ParticleTypes.CLOUD,
                        p.getX() - v.x * 2.0D + (p.getRandom().nextDouble() - 0.5D) * 0.6D,
                        p.getY() + 0.5D + p.getRandom().nextDouble() * 1.2D,
                        p.getZ() - v.z * 2.0D + (p.getRandom().nextDouble() - 0.5D) * 0.6D,
                        0, 0, 0);
            }
        }

        private static void climbFx(LocalPlayer p, boolean moving) {
            if (!moving || p.tickCount % 3 != 0) return;
            BlockPos bp;
            double bx, by, bz;
            if (climbType == 1) {
                bp = BlockPos.containing(p.getX() + climbPush.x * 5.0D, p.getY() + 1.2D, p.getZ() + climbPush.z * 5.0D);
                bx = p.getX() + climbPush.x * 3.0D;
                by = p.getY() + 0.5D + p.getRandom().nextDouble() * 1.5D;
                bz = p.getZ() + climbPush.z * 3.0D;
            } else {
                bp = BlockPos.containing(p.getX(), p.getBoundingBox().maxY + 0.3D, p.getZ());
                bx = p.getX() + (p.getRandom().nextDouble() - 0.5D) * 0.6D;
                by = p.getBoundingBox().maxY + 0.1D;
                bz = p.getZ() + (p.getRandom().nextDouble() - 0.5D) * 0.6D;
            }
            BlockState st = p.level().getBlockState(bp);
            if (st.isAir()) return;
            for (int i = 0; i < 3; i++) {
                p.level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, st),
                        bx + (p.getRandom().nextDouble() - 0.5D) * 0.4D, by,
                        bz + (p.getRandom().nextDouble() - 0.5D) * 0.4D, 0, 0, 0);
            }
            if (p.tickCount % 6 == 0) {
                p.level().playLocalSound(p.getX(), p.getY(), p.getZ(), st.getSoundType().getStepSound(),
                        SoundSource.PLAYERS, 0.4F, 1.2F, false);
            }
        }

        /** Birinci sahista da kostumlu kolu goster. */
        @SubscribeEvent
        public static void onArm(RenderArmEvent e) {
            AbstractClientPlayer pl = e.getPlayer();
            if (!wearingSuit(pl)) return;
            PlayerModel<AbstractClientPlayer> m = "slim".equals(pl.getModelName())
                    ? SpiderSuitLayer.fpSlim : SpiderSuitLayer.fpWide;
            if (m == null) return;
            m.attackTime = 0.0F;
            m.crouching = false;
            m.swimAmount = 0.0F;
            m.setupAnim(pl, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
            ModelPart arm = e.getArm() == HumanoidArm.RIGHT ? m.rightArm : m.leftArm;
            arm.visible = true;
            arm.xRot = 0.0F;
            arm.render(e.getPoseStack(),
                    e.getMultiBufferSource().getBuffer(RenderType.entityCutoutNoCull(SpiderSuitLayer.TEXTURE)),
                    e.getPackedLight(), OverlayTexture.NO_OVERLAY);
            e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onFov(ViewportEvent.ComputeFov e) {
            fovBonus = Mth.lerp(0.08F, fovBonus, fovTarget);
            if (Math.abs(fovBonus) > 0.01F) e.setFOV(e.getFOV() + fovBonus);
        }

        @SubscribeEvent
        public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
            rollSmooth = Mth.lerp(0.08F, rollSmooth, rollTarget);
            if (Math.abs(rollSmooth) > 0.01F) e.setRoll(e.getRoll() + rollSmooth);
        }

        // ============ PURUZSUZ AG SERIDI (uzun, tek parca) ============
        @SubscribeEvent
        public static void onRender(RenderLevelStageEvent e) {
            if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null) return;
            if (anchor == null && BOLTS.isEmpty()) return;

            Vec3 cam = e.getCamera().getPosition();
            PoseStack ps = e.getPoseStack();
            ps.pushPose();
            ps.translate(-cam.x, -cam.y, -cam.z);
            Matrix4f m = ps.last().pose();
            MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();

            if (anchor != null) { // sallanma / zip agi
                float pt = e.getPartialTick();
                Vec3 eye = p.getEyePosition(pt);
                Vec3 look = p.getViewVector(pt);
                Vec3 right = look.cross(UP);
                right = right.lengthSqr() < 1.0E-4D ? new Vec3(1, 0, 0) : right.normalize();
                Vec3 start = eye.add(right.scale(0.28D)).add(0, -0.3D, 0).add(look.scale(0.35D));
                drawRibbon(bs, m, start, anchor, 0.014D); // ince, duz cizgi
            }

            for (Bolt bo : BOLTS) { // seken / yapistirici ag cizgileri
                for (int i = 0; i + 1 < bo.pts.size(); i++) {
                    Vec3 a = bo.pts.get(i);
                    if (i == 0) a = a.add(0, -0.3D, 0);
                    drawRibbon(bs, m, a, bo.pts.get(i + 1), 0.014D);
                }
            }
            ps.popPose();
        }

        private static void drawRibbon(MultiBufferSource.BufferSource bs, Matrix4f m, Vec3 a, Vec3 b, double w) {
            Vec3 dir = b.subtract(a);
            if (dir.lengthSqr() < 1.0E-6D) return;
            dir = dir.normalize();
            Vec3 ref = Math.abs(dir.y) > 0.99D ? new Vec3(1, 0, 0) : UP;
            Vec3 o1 = dir.cross(ref).normalize().scale(w);
            Vec3 o2 = dir.cross(o1).normalize().scale(w);
            strip(bs, m, a, b, o1);
            strip(bs, m, a, b, o2);
        }

        private static void strip(MultiBufferSource.BufferSource bs, Matrix4f m, Vec3 a, Vec3 b, Vec3 o) {
            VertexConsumer vc = bs.getBuffer(RenderType.leash());
            vtx(vc, m, a.add(o));
            vtx(vc, m, a.subtract(o));
            vtx(vc, m, b.add(o));
            vtx(vc, m, b.subtract(o));
            bs.endBatch(RenderType.leash());
        }

        private static void vtx(VertexConsumer vc, Matrix4f m, Vec3 v) {
            vc.vertex(m, (float) v.x, (float) v.y, (float) v.z)
                    .color(245, 248, 255, 255).uv2(15728880).endVertex();
        }
    }
}
