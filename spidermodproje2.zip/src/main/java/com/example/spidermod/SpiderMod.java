package com.example.spidermod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/**
 * Spider Mod (Forge 1.20.1) - IRON SPIDER nano kostumu
 *
 *  - G: NANO KOSTUM giy/cikar (kostum envanterde olmali; nano efektiyle vucuda gecer)
 *  - Kostum: tum vucut Iron Spider, sirtta 4 mekanik bacak, birinci sahista da gorunur
 *  - Kostumle: biraz daha yuksege zipla, biraz daha hizli kos, dusme hasari azalir
 *  - Y: Web Shooter ac/kapat
 *  - Web Shooter ACIKKEN bos elle SAG TIKI BASILI TUT:
 *        normal    -> ag atilir, sallanirsin (asagi inerken hizlanirsin, SPACE: ipi birak ve firla)
 *        SHIFT ile -> WEB ZIP: baktigin yere hizla atilirsin
 *                     duvara bakarsan duvara yapisirsin, tavana bakarsan tavana yapisirsin
 *  - Duvar tirmanma: duvarin onunde SHIFT + SPACE (bir kez) -> mod acilir
 *        W yukari, S asagi, SPACE duvardan siçra, SHIFT+SPACE birak
 *        yukarida tavan varsa otomatik TAVANA gecer (WASD ile tavanda yuru)
 *  - Efektler: puruzsuz ag seridi, sallanirken FOV/egilme, tirmanirken parcacik/ses
 */
@Mod(SpiderMod.MODID)
public class SpiderMod {
    public static final String MODID = "spidermod";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> SPIDER_SUIT = ITEMS.register("spider_suit",
            () -> new SpiderSuitItem(SuitMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));

    public SpiderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        bus.addListener(this::addCreative);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(Net::register);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) {
            e.accept(SPIDER_SUIT);
        }
    }

    public static boolean wearingSuit(Player p) {
        return p.getItemBySlot(EquipmentSlot.CHEST).is(SPIDER_SUIT.get());
    }

    // ---------------- SUNUCU + ISTEMCI ----------------
    @Mod.EventBusSubscriber(modid = MODID)
    public static class CommonEvents {
        @SubscribeEvent
        public static void onJump(LivingEvent.LivingJumpEvent e) {
            if (e.getEntity() instanceof Player p && wearingSuit(p)) {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x, v.y + 0.08D, v.z); // biraz daha yuksege zipla
            }
        }

        @SubscribeEvent
        public static void onFall(LivingFallEvent e) {
            if (e.getEntity() instanceof Player p && wearingSuit(p)) {
                e.setDamageMultiplier(0.25F);
            }
        }
    }

    // ---------------- ISTEMCI (MOD BUS) ----------------
    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            e.register(ClientEvents.WEB_KEY);
            e.register(ClientEvents.SUIT_KEY);
        }

        @SubscribeEvent
        public static void layerDefs(EntityRenderersEvent.RegisterLayerDefinitions e) {
            e.registerLayerDefinition(SpiderSuitLayer.WIDE, () -> SpiderSuitLayer.createLayer(false));
            e.registerLayerDefinition(SpiderSuitLayer.SLIM, () -> SpiderSuitLayer.createLayer(true));
            e.registerLayerDefinition(IronLegsModel.LAYER, IronLegsModel::createLayer);
        }

        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers e) {
            for (String skin : e.getSkins()) {
                PlayerRenderer r = e.getSkin(skin);
                if (r != null) r.addLayer(new SpiderSuitLayer(r, e.getEntityModels()));
            }
        }
    }

    // ---------------- ISTEMCI (FORGE BUS) ----------------
    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT)
    public static class ClientEvents {
        public static final KeyMapping WEB_KEY =
                new KeyMapping("key.spidermod.web_toggle", GLFW.GLFW_KEY_Y, "key.categories.spidermod");
        public static final KeyMapping SUIT_KEY =
                new KeyMapping("key.spidermod.suit_toggle", GLFW.GLFW_KEY_G, "key.categories.spidermod");

        private static final Vec3 UP = new Vec3(0, 1, 0);

        // ag durumu
        private static boolean webActive = false;
        private static Vec3 anchor = null;
        private static Direction anchorFace = Direction.UP;
        private static double ropeLen = 0;
        private static boolean zip = false;
        private static boolean fired = false;
        private static int webAge = 0;
        private static int zipTicks = 0;

        // tirmanma durumu: 0 = yok, 1 = duvar, 2 = tavan
        private static int climbType = 0;
        private static Vec3 climbPush = Vec3.ZERO;
        private static int lostContact = 0;
        private static boolean prevJump = false;

        // gorsel efektler
        private static float fovTarget = 0F;
        private static float fovBonus = 0F;
        private static float rollTarget = 0F;
        private static float rollSmooth = 0F;

        // ============ ANA TICK ============
        @SubscribeEvent
        public static void onTick(TickEvent.PlayerTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            if (!(e.player instanceof LocalPlayer p)) return;
            Minecraft mc = Minecraft.getInstance();

            boolean suit = wearingSuit(p);
            boolean jumpEdge = p.input.jumping && !prevJump; // SPACE'e yeni basildi
            prevJump = p.input.jumping;

            while (SUIT_KEY.consumeClick()) { // nano kostum giy/cikar
                Net.CHANNEL.sendToServer(new ToggleSuitPacket());
            }

            while (WEB_KEY.consumeClick()) {
                if (!suit) {
                    p.displayClientMessage(Component.literal("§cOrumcek kostumunu giymelisin!"), true);
                } else {
                    webActive = !webActive;
                    p.displayClientMessage(Component.literal(
                            webActive ? "§aWeb Shooter: ACIK" : "§7Web Shooter: KAPALI"), true);
                }
            }
            if (!suit) webActive = false;

            boolean holding = webActive && mc.screen == null
                    && mc.options.keyUse.isDown()
                    && p.getMainHandItem().isEmpty();

            if (!holding || p.isDeadOrDying()) {
                anchor = null;
                fired = false;
            } else if (!fired) {
                fired = true;
                HitResult hit = p.pick(60.0D, 1.0F, false);
                if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
                    anchor = bhr.getLocation();
                    anchorFace = bhr.getDirection();
                    zip = p.isShiftKeyDown();
                    ropeLen = Math.max(3.0D, anchor.distanceTo(p.getEyePosition()) * 0.85D);
                    webAge = 0;
                    zipTicks = 0;
                    climbType = 0;
                    p.swing(InteractionHand.MAIN_HAND);
                    p.level().playLocalSound(p.getX(), p.getY(), p.getZ(),
                            SoundEvents.FISHING_BOBBER_THROW, SoundSource.PLAYERS, 1.0F, 1.3F, false);
                    for (int i = 0; i < 8; i++) { // ag carpma efekti
                        p.level().addParticle(ParticleTypes.CLOUD, anchor.x, anchor.y, anchor.z,
                                (p.getRandom().nextDouble() - 0.5D) * 0.1D,
                                (p.getRandom().nextDouble() - 0.5D) * 0.1D,
                                (p.getRandom().nextDouble() - 0.5D) * 0.1D);
                    }
                }
            }

            fovTarget = 0F;
            rollTarget = 0F;

            if (anchor != null) {
                tickWeb(p, jumpEdge);
            } else {
                tickClimb(p, suit, jumpEdge);
            }
        }

        // ============ AG: SALLANMA + ZIP ============
        private static void tickWeb(LocalPlayer p, boolean jumpEdge) {
            climbType = 0;
            webAge++;

            Vec3 eye = p.getEyePosition();
            Vec3 to = anchor.subtract(eye);
            double d = to.length();
            if (d < 0.3D) {
                anchor = null;
                return;
            }
            Vec3 dir = to.scale(1.0D / d);
            Vec3 v = p.getDeltaMovement();

            if (zip) {
                // WEB ZIP: baktigin noktaya dogru hizli atilim (SPACE'e bakmaz)
                zipTicks++;
                if (zipArrived(p, d)) {
                    arrive(p);
                    return;
                }
                v = dir.scale(Math.min(0.95D, 0.35D + d * 0.06D));
            } else {
                // SALLANMA
                if (jumpEdge) { // SPACE'e yeni basinca birak + firla (hiz yuksekse daha cok firlar)
                    double boost = 1.25D + Math.min(0.35D, v.length() * 0.3D);
                    p.setDeltaMovement(v.scale(boost).add(0, 0.2D, 0));
                    anchor = null;
                    return;
                }
                if (d > ropeLen) {
                    double radial = v.dot(dir);
                    if (radial < 0) v = v.subtract(dir.scale(radial));
                    v = v.add(dir.scale(Math.min(0.5D, (d - ropeLen) * 0.15D)));
                }
                if (v.y < -0.05D && v.length() < 1.9D) { // asagi inerken hizlan
                    v = v.scale(1.035D);
                }
                if (p.input.forwardImpulse > 0) {
                    v = v.add(p.getLookAngle().scale(0.03D));
                }
                if (v.length() > 2.2D) v = v.normalize().scale(2.2D);
                // sallanirken yana egilme
                Vec3 right = p.getLookAngle().cross(UP);
                if (right.lengthSqr() > 1.0E-4D) {
                    double lateral = v.dot(right.normalize());
                    rollTarget = (float) Mth.clamp(-lateral * 30.0D, -14.0D, 14.0D);
                }
            }

            p.setDeltaMovement(v);
            p.fallDistance = 0;

            double speed = v.length();
            fovTarget = (float) Mth.clamp((speed - 0.25D) * 35.0D, 0.0D, 18.0D);
            windFx(p, v, speed);
        }

        private static boolean zipArrived(LocalPlayer p, double d) {
            if (zipTicks > 40) return true;
            if (anchorFace == Direction.UP) return d < 2.2D;
            if (anchorFace == Direction.DOWN) return d < 0.6D || (d < 3.0D && ceilingAbove(p));
            return d < 0.8D || (d < 3.0D && wallDir(p) != null);
        }

        /** Zip bitince: duvara bakildiysa duvara, tavana bakildiysa tavana yapis. */
        private static void arrive(LocalPlayer p) {
            Direction f = anchorFace;
            anchor = null;
            p.setDeltaMovement(Vec3.ZERO);
            if (f.getAxis().isHorizontal()) {
                climbPush = new Vec3(-f.getStepX() * 0.1D, 0, -f.getStepZ() * 0.1D);
                climbType = 1;
                lostContact = 0;
                p.displayClientMessage(Component.literal("§aDuvara yapistin"), true);
            } else if (f == Direction.DOWN) {
                climbType = 2;
                lostContact = 0;
                p.displayClientMessage(Component.literal("§aTavana yapistin"), true);
            }
        }

        // ============ DUVAR / TAVAN TIRMANMA ============
        private static void tickClimb(LocalPlayer p, boolean suit, boolean jumpEdge) {
            if (!suit || p.isInWater() || p.isDeadOrDying()) climbType = 0;

            if (climbType != 0) {
                if (jumpEdge) {
                    boolean drop = p.isShiftKeyDown() || climbType == 2;
                    climbType = 0;
                    if (!drop) { // duvardan siçra
                        Vec3 look = p.getLookAngle();
                        p.setDeltaMovement(look.x * 0.6D, 0.6D, look.z * 0.6D);
                    }
                    return;
                }

                boolean moving;
                if (climbType == 1) {
                    // ---- DUVAR ----
                    if (wallDir(p) != null) lostContact = 0; else lostContact++;
                    if (lostContact > 6) { // duvarin tepesi
                        climbType = 0;
                        return;
                    }
                    double vy = p.input.forwardImpulse > 0 ? 0.2D : (p.input.forwardImpulse < 0 ? -0.2D : 0.0D);
                    if (vy > 0 && ceilingAbove(p)) { // yukarida tavan var -> tavana gec
                        climbType = 2;
                        lostContact = 0;
                        p.setDeltaMovement(Vec3.ZERO);
                        p.displayClientMessage(Component.literal("§aTavana gectin"), true);
                        return;
                    }
                    if (vy < 0 && p.onGround()) {
                        climbType = 0;
                        return;
                    }
                    p.setDeltaMovement(climbPush.x, vy, climbPush.z);
                    moving = vy != 0;
                } else {
                    // ---- TAVAN ----
                    if (ceilingAbove(p)) lostContact = 0; else lostContact++;
                    if (lostContact > 6) { // tavanin kenari
                        climbType = 0;
                        return;
                    }
                    double fx = Math.signum(p.input.leftImpulse);
                    double fz = Math.signum(p.input.forwardImpulse);
                    double yaw = Math.toRadians(p.getYRot());
                    double mx = fx * Math.cos(yaw) - fz * Math.sin(yaw);
                    double mz = fz * Math.cos(yaw) + fx * Math.sin(yaw);
                    double len = Math.sqrt(mx * mx + mz * mz);
                    if (len > 1.0E-4D) { mx /= len; mz /= len; }
                    p.setDeltaMovement(mx * 0.18D, 0.1D, mz * 0.18D);
                    moving = len > 1.0E-4D;
                }
                p.fallDistance = 0;
                climbFx(p, moving);
                return;
            }

            // ---- MODU AC: SHIFT + SPACE (duvar veya tavan yakininda) ----
            if (suit && jumpEdge && p.isShiftKeyDown() && !p.isInWater()) {
                Direction wd = wallDir(p);
                if (wd != null) {
                    climbPush = new Vec3(wd.getStepX() * 0.1D, 0, wd.getStepZ() * 0.1D);
                    climbType = 1;
                    lostContact = 0;
                    p.displayClientMessage(Component.literal("§aDuvara tirmanma: ACIK"), true);
                } else if (ceilingAbove(p)) {
                    climbType = 2;
                    lostContact = 0;
                    p.displayClientMessage(Component.literal("§aTavana tirmanma: ACIK"), true);
                }
            }
        }

        /** Yakinda duvar varsa o yonu verir (once bakilan yon). */
        private static Direction wallDir(LocalPlayer p) {
            AABB bb = p.getBoundingBox().inflate(0, -0.1D, 0);
            Direction first = p.getDirection();
            if (!p.level().noCollision(p, bb.move(first.getStepX() * 0.2D, 0, first.getStepZ() * 0.2D))) return first;
            for (Direction d : Direction.Plane.HORIZONTAL) {
                if (d == first) continue;
                if (!p.level().noCollision(p, bb.move(d.getStepX() * 0.2D, 0, d.getStepZ() * 0.2D))) return d;
            }
            return null;
        }

        private static boolean ceilingAbove(LocalPlayer p) {
            AABB bb = p.getBoundingBox().inflate(-0.1D, 0, -0.1D).move(0, 0.15D, 0);
            return !p.level().noCollision(p, bb);
        }

        // ============ EFEKTLER ============
        private static void windFx(LocalPlayer p, Vec3 v, double speed) {
            if (speed < 0.5D) return;
            for (int i = 0; i < 2; i++) {
                p.level().addParticle(ParticleTypes.CLOUD,
                        p.getX() - v.x * 2.0D + (p.getRandom().nextDouble() - 0.5D) * 0.6D,
                        p.getY() + 0.5D + p.getRandom().nextDouble() * 1.2D,
                        p.getZ() - v.z * 2.0D + (p.getRandom().nextDouble() - 0.5D) * 0.6D,
                        0, 0, 0);
            }
        }

        private static void climbFx(LocalPlayer p, boolean moving) {
            if (!moving || p.tickCount % 3 != 0) return;
            BlockPos bp;
            double bx, by, bz;
            if (climbType == 1) {
                bp = BlockPos.containing(p.getX() + climbPush.x * 5.0D, p.getY() + 1.2D, p.getZ() + climbPush.z * 5.0D);
                bx = p.getX() + climbPush.x * 3.0D;
                by = p.getY() + 0.5D + p.getRandom().nextDouble() * 1.5D;
                bz = p.getZ() + climbPush.z * 3.0D;
            } else {
                bp = BlockPos.containing(p.getX(), p.getBoundingBox().maxY + 0.3D, p.getZ());
                bx = p.getX() + (p.getRandom().nextDouble() - 0.5D) * 0.6D;
                by = p.getBoundingBox().maxY + 0.1D;
                bz = p.getZ() + (p.getRandom().nextDouble() - 0.5D) * 0.6D;
            }
            BlockState st = p.level().getBlockState(bp);
            if (st.isAir()) return;
            for (int i = 0; i < 3; i++) {
                p.level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, st),
                        bx + (p.getRandom().nextDouble() - 0.5D) * 0.4D, by,
                        bz + (p.getRandom().nextDouble() - 0.5D) * 0.4D, 0, 0, 0);
            }
            if (p.tickCount % 6 == 0) {
                p.level().playLocalSound(p.getX(), p.getY(), p.getZ(), st.getSoundType().getStepSound(),
                        SoundSource.PLAYERS, 0.4F, 1.2F, false);
            }
        }

        /** Birinci sahista da kostumlu kolu goster. */
        @SubscribeEvent
        public static void onArm(RenderArmEvent e) {
            AbstractClientPlayer pl = e.getPlayer();
            if (!wearingSuit(pl)) return;
            PlayerModel<AbstractClientPlayer> m = "slim".equals(pl.getModelName())
                    ? SpiderSuitLayer.fpSlim : SpiderSuitLayer.fpWide;
            if (m == null) return;
            m.attackTime = 0.0F;
            m.crouching = false;
            m.swimAmount = 0.0F;
            m.setupAnim(pl, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
            ModelPart arm = e.getArm() == HumanoidArm.RIGHT ? m.rightArm : m.leftArm;
            arm.visible = true;
            arm.xRot = 0.0F;
            arm.render(e.getPoseStack(),
                    e.getMultiBufferSource().getBuffer(RenderType.entityCutoutNoCull(SpiderSuitLayer.TEXTURE)),
                    e.getPackedLight(), OverlayTexture.NO_OVERLAY);
            e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onFov(ViewportEvent.ComputeFov e) {
            fovBonus = Mth.lerp(0.08F, fovBonus, fovTarget);
            if (Math.abs(fovBonus) > 0.01F) e.setFOV(e.getFOV() + fovBonus);
        }

        @SubscribeEvent
        public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
            rollSmooth = Mth.lerp(0.08F, rollSmooth, rollTarget);
            if (Math.abs(rollSmooth) > 0.01F) e.setRoll(e.getRoll() + rollSmooth);
        }

        // ============ PURUZSUZ AG SERIDI (uzun, tek parca) ============
        @SubscribeEvent
        public static void onRender(RenderLevelStageEvent e) {
            if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
            if (anchor == null) return;
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null) return;

            float pt = e.getPartialTick();
            Vec3 eye = p.getEyePosition(pt);
            Vec3 look = p.getViewVector(pt);
            Vec3 right = look.cross(UP);
            right = right.lengthSqr() < 1.0E-4D ? new Vec3(1, 0, 0) : right.normalize();
            Vec3 start = eye.add(right.scale(0.28D)).add(0, -0.3D, 0).add(look.scale(0.35D));

            // ag elden hedefe hizla uzanir (3 tick)
            double prog = Math.min(1.0D, (webAge + pt) / 3.0D);
            Vec3 end = start.add(anchor.subtract(start).scale(prog));

            Vec3 cam = e.getCamera().getPosition();
            PoseStack ps = e.getPoseStack();
            ps.pushPose();
            ps.translate(-cam.x, -cam.y, -cam.z);
            Matrix4f m = ps.last().pose();
            MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
            drawRibbon(bs, m, start, end, zip ? 0.035D : 0.028D);
            ps.popPose();
        }

        private static void drawRibbon(MultiBufferSource.BufferSource bs, Matrix4f m, Vec3 a, Vec3 b, double w) {
            Vec3 dir = b.subtract(a);
            if (dir.lengthSqr() < 1.0E-6D) return;
            dir = dir.normalize();
            Vec3 ref = Math.abs(dir.y) > 0.99D ? new Vec3(1, 0, 0) : UP;
            Vec3 o1 = dir.cross(ref).normalize().scale(w);
            Vec3 o2 = dir.cross(o1).normalize().scale(w);
            strip(bs, m, a, b, o1);
            strip(bs, m, a, b, o2);
        }

        private static void strip(MultiBufferSource.BufferSource bs, Matrix4f m, Vec3 a, Vec3 b, Vec3 o) {
            VertexConsumer vc = bs.getBuffer(RenderType.leash());
            vtx(vc, m, a.add(o));
            vtx(vc, m, a.subtract(o));
            vtx(vc, m, b.add(o));
            vtx(vc, m, b.subtract(o));
            bs.endBatch(RenderType.leash());
        }

        private static void vtx(VertexConsumer vc, Matrix4f m, Vec3 v) {
            vc.vertex(m, (float) v.x, (float) v.y, (float) v.z)
                    .color(245, 248, 255, 255).uv2(15728880).endVertex();
        }
    }
}
