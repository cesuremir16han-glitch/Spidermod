package com.example.spidermod;

import software.bernie.geckolib.renderer.GeoArmorRenderer;

/** Oktopus kollari icin GeckoLib zirh cizici. */
public class OctoArmsRenderer extends GeoArmorRenderer<OctoArmsItem> {
    public OctoArmsRenderer() {
        super(new OctoArmsGeoModel());
    }
}
